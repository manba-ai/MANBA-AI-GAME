"""Single target facts shared by authoring, packaging and generated runtimes."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTRACT_PATH = ROOT / 'contracts/km013-st7789-i8080-v1.json'
PROFILE = json.loads(CONTRACT_PATH.read_text())
if PROFILE['schema_version'] != 1 or PROFILE['viewport'] != {'width': 320, 'height': 240}:
    raise ValueError('Unsupported game target contract')
LIMITS = {**PROFILE['device_limits'],**PROFILE['host_policy']['snapshot_limits']}
BITMAP_V2 = PROFILE['bitmap_v2']
GRAPHICS_V2 = PROFILE['graphics_v2']
RESOURCES_V2 = PROFILE['resources_v2']
VIEWPORT = PROFILE['viewport']
CONTRACT_SHA256 = hashlib.sha256(CONTRACT_PATH.read_bytes()).hexdigest()


def limits_for(runtime_profile='legacy'):
    if runtime_profile not in ('legacy','resources-v2'):
        raise ValueError('Unknown runtime profile')
    return {**LIMITS, **(RESOURCES_V2 if runtime_profile=='resources-v2' else {})}


def provenance():
    def digest(path):
        return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    return {'target': PROFILE['id'], 'contract_sha256': CONTRACT_SHA256,
            'native_runner_sha256': digest(ROOT / '.tools/bin/game-runner'),
            'play_runtime_sha256': digest(ROOT / 'runtime/play-runtime.cjs'),
            'validator_sha256': digest(ROOT / 'compiler/authoring/runtime.py')}
