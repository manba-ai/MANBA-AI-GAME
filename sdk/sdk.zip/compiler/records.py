"""Records identity declared by each authored game."""
import re


def integration(spec):
    embedded = re.search(r'^-- @records-key ([0-9a-f]{64})$', spec['code'], re.M)
    if not embedded:
        raise ValueError('Game source requires a unique @records-key; see docs/SDK.md')
    return {'version': 1, 'key': embedded.group(1)}, ''
