"""Bounded, JSON-safe authoring failures for jobs and model repair."""
import json
from pydantic import ValidationError


class DiagnosticError(ValueError):
    def __init__(self, message, *, code='validation_failed', stage='runtime', **details):
        super().__init__(message)
        self.code = code
        self.diagnostic = {'schema_version': 1, 'code': code, 'stage': stage,
                           'message': str(message)[:1800], **details}


def diagnostic_for(error, *, stage='validation', artifact_sha=None):
    value = dict(getattr(error, 'diagnostic', {}))
    if not value:
        message = str(error)[:1800]
        code = getattr(error, 'code', 'validation_failed')
        if isinstance(error, ValidationError):
            code = 'schema_invalid'
            fields = [{'path': '.'.join(map(str, item['loc'])), 'type': item['type'],
                       'message': item['msg'][:240]} for item in error.errors(include_input=False, include_url=False)[:12]]
        else:
            fields = []
            for text,kind,phase in [('Lua 语法','lua_syntax','compiling'),('instruction budget','instruction_limit','runtime'),('memory','memory_limit','runtime'),('not enough memory','memory_limit','runtime'),('draw exceeds','draw_limit','drawing'),('bitmap pixel budget','bitmap_work_limit','drawing'),('snapshot exceeds','snapshot_limit','snapshot'),('游戏包上限','package_limit','compiling')]:
                if text in message:code=kind;stage=phase;break
        value = {'schema_version': 1, 'code': code, 'stage': stage, 'message': message}
        if fields:
            value['fields'] = fields
    if artifact_sha:
        value['artifact_sha256'] = artifact_sha
    return value


def repair_feedback(error, **options):
    return json.dumps(diagnostic_for(error, **options), ensure_ascii=False, separators=(',', ':'))
