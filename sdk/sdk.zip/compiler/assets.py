"""Compile semantic sprite/animation metadata into bounded Lua data bindings."""
import copy
import math
import re
from .bitmaps import normalize
from .game_contract import limits_for

NAME=re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,47}$')

def animations(source,sprites,*,runtime_profile='legacy'):
    LIMITS=limits_for(runtime_profile)
    if not isinstance(source,dict) or len(source)>LIMITS['bitmap_count']:raise ValueError(f"animations 必须为最多{LIMITS['bitmap_count']}项的对象")
    result={}
    for name,animation in source.items():
        if not isinstance(name,str) or not NAME.fullmatch(name) or not isinstance(animation,dict) or set(animation)-{'frames','frame_ms','durations_ms','loop'}:raise ValueError('动画名称或字段无效')
        frames=animation.get('frames')
        if not isinstance(frames,list) or not 1<=len(frames)<=32 or any(not isinstance(f,str) or f not in sprites for f in frames):raise ValueError('动画帧引用未知 sprite：'+name)
        if 'durations_ms' in animation and 'frame_ms' in animation:raise ValueError('动画时长不能重复定义')
        durations=animation.get('durations_ms',[animation.get('frame_ms',100)]*len(frames))
        if not isinstance(durations,list) or len(durations)!=len(frames) or any(type(d) is not int or not 1<=d<=60000 for d in durations):raise ValueError('动画时长必须为每帧1–60000ms')
        loop=animation.get('loop',True)
        if type(loop) is not bool:raise ValueError('动画 loop 必须为布尔值')
        result[name]={'frames':[sprites[f] for f in frames],'durations_ms':durations,'loop':loop}
    return result

def bind_manifest(manifest,bitmaps,data=None,code='',*,runtime_profile='legacy'):
    normalize(bitmaps,runtime_profile=runtime_profile)
    if not isinstance(manifest,dict) or manifest.get('format')!='bitmap-v1' or set(manifest)-{'format','sprites','records','pixels','source_manifest','animations'}:raise ValueError('sprite_manifest 格式无效')
    if 'source_manifest' in manifest and (not isinstance(manifest['source_manifest'],str) or len(manifest['source_manifest'])>255):raise ValueError('source_manifest 必须为简短来源标识')
    sprites=manifest.get('sprites');records=manifest.get('records')
    if not isinstance(sprites,dict) or len(sprites)!=len(bitmaps) or any(not isinstance(n,str) or not NAME.fullmatch(n) or type(i) is not int for n,i in sprites.items()) or set(sprites.values())!=set(range(1,len(bitmaps)+1)):raise ValueError('sprite 名称和编号必须唯一且与位图一一对应')
    if not isinstance(records,list) or len(records)!=len(sprites):raise ValueError('sprite records 不完整')
    metadata={}
    for record in records:
        if not isinstance(record,dict) or set(record)-{'id','name','width','height','pivot','role'}:raise ValueError('sprite record 字段无效')
        name=record.get('name');ident=record.get('id')
        if type(ident) is not int or not isinstance(name,str) or name not in sprites or name in metadata or sprites[name]!=ident:raise ValueError('sprite record 重复或编号不匹配')
        bitmap=bitmaps[ident-1]
        if any(type(record.get(k)) is not int or record[k]!=bitmap[k] for k in ('width','height')):raise ValueError('sprite record 尺寸不匹配')
        item={k:record[k] for k in ('width','height')}
        if 'pivot' in record:
            pivot=record['pivot']
            if not isinstance(pivot,list) or len(pivot)!=2 or any(type(v) not in (int,float) or not math.isfinite(v) for v in pivot):raise ValueError('sprite pivot 无效')
            item['pivot']=pivot
        if 'role' in record and (not isinstance(record['role'],str) or len(record['role'])>32):raise ValueError('sprite role 无效')
        metadata[name]=item
    if 'pixels' in manifest and manifest['pixels']!=sum(b['width']*b['height'] for b in bitmaps):raise ValueError('sprite pixels 不匹配')
    bindings={'sprites':sprites,'sprite_meta':metadata,'animations':animations(manifest.get('animations',{}),sprites,runtime_profile=runtime_profile)}
    merged=copy.deepcopy(data or {})
    for key,value in bindings.items():
        if key in merged and merged[key]!=value:raise ValueError('data.'+key+' 与编译素材绑定冲突')
        merged[key]=copy.deepcopy(value)
    # Inspect Lua tokens so comments/strings do not create false references.
    from .lua import _TOKEN
    tokens=[m.group() for m in _TOKEN.finditer(code) if not m.group().startswith('--')]
    def accessor(pos):
        if pos+1<len(tokens) and tokens[pos]=='.':return tokens[pos+1],pos+2
        if pos+2<len(tokens) and tokens[pos]=='[' and tokens[pos+2]==']':
            literal=tokens[pos+1]
            if len(literal)>2 and literal[0] in ('"',"'") and literal[-1]==literal[0] and '\\' not in literal:return literal[1:-1],pos+3
        return None,pos
    for i,token in enumerate(tokens):
        if token!='game_data':continue
        kind,pos=accessor(i+1)
        if kind not in bindings:continue
        name,_=accessor(pos)
        if name is not None and name not in bindings[kind]:raise ValueError('未知素材引用：game_data.'+kind+'.'+name)
    return merged
