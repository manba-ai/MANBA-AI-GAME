"""Validate and pack precompiled title artwork."""
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class Strict(BaseModel):
    model_config = ConfigDict(extra='forbid')

class CoverHD(Strict):
    """Six opaque tiles compiled from a 320x240 title image."""
    version: Literal[4] = 4
    title: str = Field(min_length=1, max_length=24, pattern=r'^[A-Z0-9 !:.-]+$')
    description: str = Field(min_length=20, max_length=2000)
    bitmaps: list[dict] = Field(min_length=6, max_length=6)

    @model_validator(mode='after')
    def tiles(self):
        from .bitmaps import normalize, unpack
        normalize(self.bitmaps)
        for i, item in enumerate(self.bitmaps):
            b = unpack(item)
            if 'alpha' not in b or (b['width'], b['height']) != ((128,128,64)[i%3], (128,112)[i//3]):
                raise ValueError('高清封面必须为320×240原生六图块')
            if any(b['alpha'][int(b['pixels'][j:j+2],16)] != 'f' for j in range(0,len(b['pixels']),2)):
                raise ValueError('高清封面必须不透明')
        return self


def compile_art(design, existing, *, runtime_profile='legacy'):
    from .bitmaps import normalize, unpack
    design = CoverHD.model_validate(design)
    tiles = [unpack(b) for b in design.bitmaps]
    bitmaps = [*existing, *tiles]
    normalize(bitmaps,runtime_profile=runtime_profile)
    scene = [['c', 0]]
    for i, b in enumerate(tiles):
        scene.append(['s',len(existing)+i+1,(i%3)*128,(i//3)*128,False,b['width'],b['height']])
    return bitmaps, {'version':1,'title':design.title,'description':design.description,'resolution':[320,240],'scene':scene}

def validate_asset(cover, bitmaps):
    fields={'version', 'title', 'description', 'scene'}
    if not isinstance(cover, dict) or set(cover) not in (fields,fields|{'resolution'}) or cover['version'] != 1:
        raise ValueError('街机封面资源格式无效')
    scene = cover['scene']
    import re
    if not isinstance(cover['title'], str) or not re.fullmatch(r'[A-Z0-9 !:.-]{1,24}', cover['title']):
        raise ValueError('街机封面标题无效')
    size=cover.get('resolution',[160,120])
    if not isinstance(size,list) or any(type(v) is not int for v in size) or size not in ([320,240],[160,120],[80,60],[64,48],[32,24]):raise ValueError('街机封面分辨率无效')
    width,height=size;factor=320//width
    tile=128 if width==320 else min(64,240//factor)
    tiles=[(x,y) for y in range(0,height,tile) for x in range(0,width,tile)]
    if not isinstance(cover['description'], str) or not 20 <= len(cover['description']) <= 2000 or not isinstance(scene, list) or len(scene) != len(tiles)+1:
        raise ValueError('街机封面资源格式无效')
    if not isinstance(scene[0], list) or len(scene[0]) != 2 or scene[0][0] != 'c' or type(scene[0][1]) is not int or not 0 <= scene[0][1] <= 65535:
        raise ValueError('街机封面背景无效')
    ids = []
    for command, (x, y) in zip(scene[1:],tiles):
        w, h = min(tile, width-x), min(tile, height-y)
        if not isinstance(command, list) or len(command) != 7 or command[0] != 's' or type(command[1]) is not int or not 1 <= command[1] <= len(bitmaps) or command[2:] != [x*factor, y*factor, False, w*factor, h*factor]:
            raise ValueError('街机封面位图布局无效')
        bitmap = bitmaps[command[1]-1]
        if (bitmap['width'], bitmap['height']) != (w, h):
            raise ValueError('街机封面位图尺寸无效')
        ids.append(command[1])
    if len(set(ids)) != len(tiles):
        raise ValueError('街机封面位图引用重复')
    return cover


def lua_source(cover):
    """Append inside authored scope so existing H.paint retains special menus."""
    from .packages import ROOT, lua_value
    return '\nlocal cover_scene=' + lua_value(cover['scene']) + '\n' + (ROOT/'games/cover.lua').read_text()
