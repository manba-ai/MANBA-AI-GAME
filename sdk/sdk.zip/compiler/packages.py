"""Lua game package encoding and validation."""
import json
import re
import subprocess
import tempfile
from pathlib import Path
from .game_contract import PROFILE,VIEWPORT,limits_for

ROOT = Path(__file__).resolve().parents[1]

def lua_value(value):
    if isinstance(value,bool): return 'true' if value else 'false'
    if isinstance(value,(int,float)): return str(value)
    if isinstance(value,str): return json.dumps(value,ensure_ascii=False)
    if isinstance(value,(list,tuple)): return '{'+','.join(lua_value(v) for v in value)+'}'
    if isinstance(value,dict): return '{'+','.join('['+lua_value(k)+']='+lua_value(v) for k,v in value.items())+'}'
    raise ValueError('unsupported Lua config value')

def encode(package): return json.dumps(package,ensure_ascii=False,separators=(',',':')).encode()

def validate_launcher_card(card):
    """Validate the optional 32x24 indexed image used by the native launcher."""
    if not isinstance(card,dict) or set(card)!={'width','height','palette','pixels'}:
        raise ValueError('启动器卡片字段无效')
    if card['width']!=32 or card['height']!=24:
        raise ValueError('启动器图标必须为32×24')
    if not isinstance(card['palette'],str) or len(card['palette'])!=64 or any(c not in '0123456789abcdef' for c in card['palette']):
        raise ValueError('启动器卡片调色板无效')
    if not isinstance(card['pixels'],str) or len(card['pixels'])!=768 or any(c not in '0123456789abcdef' for c in card['pixels']):
        raise ValueError('启动器卡片像素无效')
    return card

def validate_launcher_icon(icon):
    """Validate the standalone 80x80 opaque game-list icon."""
    from .bitmaps import unpack
    if not isinstance(icon,dict) or set(icon)!={'width','height','encoding','data'}:
        raise ValueError('高清图标字段无效')
    if type(icon['width']) is not int or type(icon['height']) is not int or (icon['width'],icon['height'])!=(80,80) or icon['encoding']!='indexed8-zlib':
        raise ValueError('高清图标必须为80×80 indexed8-zlib')
    bitmap=unpack(icon)
    if any(bitmap['alpha'][index]!='f' for index in bytes.fromhex(bitmap['pixels'])):
        raise ValueError('高清图标必须包含不透明背景')
    return icon

def validate(package, *, installable=False):
    if not isinstance(package,dict) or package.get('format')!='edge.game/1' or package.get('sdk')!=1:
        raise ValueError('游戏包格式或 SDK 版本不兼容')
    code=package.get('code')
    runtime_profile=package.get('runtime_profile','legacy');limits=limits_for(runtime_profile)
    if not isinstance(code,str) or len(code.encode())>limits['code_bytes'] or len(encode(package))>limits['package_bytes']:
        raise ValueError(f'游戏包上限 {limits["package_bytes"]//1024} KiB，Lua 代码上限 {limits["code_bytes"]//1024} KiB')
    if not isinstance(package.get('name'),str) or len(package['name'])>24:
        raise ValueError('游戏名称格式无效')
    features=package.get('requires',[])
    if not isinstance(features,list) or any(x not in PROFILE['package_capabilities'] for x in features) or len(features)!=len(set(features)):raise ValueError('游戏包需要不支持的 SDK 能力')
    if (runtime_profile=='resources-v2') != ('resources-v2' in features):raise ValueError('扩展资源与能力声明不一致')
    records=package.get('records')
    if (records is not None)!=('records-v1' in features):raise ValueError('最佳成绩与能力声明不一致')
    if records is not None and (not isinstance(records,dict) or set(records)!={'version','key'} or records['version']!=1 or not isinstance(records['key'],str) or not re.fullmatch('[0-9a-f]{64}',records['key'])):raise ValueError('最佳成绩存储标识无效')
    viewport=package.get('config',{}).get('viewport')
    if viewport != VIEWPORT and (installable or viewport is not None):raise ValueError('画布必须为当前设备的 320×240')
    controller=package.get('config',{}).get('ui',{}).get('controller')
    if ('abxy-v1' in features) != (controller is not None):raise ValueError('ABXY 操作与能力声明不一致')
    assets=package.get('assets',{})
    if not isinstance(assets,dict):raise ValueError('游戏资源必须为对象')
    if 'launcher_card' in assets:validate_launcher_card(assets['launcher_card'])
    if 'launcher_icon' in assets:
        validate_launcher_icon(assets['launcher_icon'])
    bitmaps=assets.get('bitmaps')
    if bitmaps is not None:
        from .bitmaps import normalize as normalize_bitmaps
        normalize_bitmaps(bitmaps,runtime_profile=runtime_profile)
        if 'bitmap-v1' not in features:raise ValueError('位图能力声明缺失')
    elif 'bitmap-v1' in features:raise ValueError('缺少位图资源')
    from .bitmaps import is_wide,ENCODING
    if any(is_wide(b) for b in (bitmaps or [])) != ('bitmap-indexed8-v2' in features):
        raise ValueError('256 色位图与能力声明不一致')
    if any(b.get('encoding')==ENCODING for b in (bitmaps or [])) != ('bitmap-zlib-v1' in features):
        raise ValueError('压缩位图与能力声明不一致')
    if 'cover' in assets:
        from .cover_art import validate_asset
        validate_asset(assets['cover'],bitmaps or [])
        if 'bitmap-scale-v1' not in features:raise ValueError('街机封面缺少缩放位图能力')
    bank=assets.get('audio')
    if bank is not None:
        from .audio import normalize,has_samples
        if normalize(bank)!=bank or 'audio-v1' not in features:raise ValueError('音频配置或能力声明不一致')
    elif 'audio-v1' in features:raise ValueError('缺少音频资源')
    from .audio import has_samples,has_compressed_samples
    if has_samples(bank)!=('audio-pcm-v1' in features):raise ValueError('PCM 音频与能力声明不一致')
    if has_compressed_samples(bank)!=('audio-pcm-zlib-v1' in features):raise ValueError('压缩 PCM 音频与能力声明不一致')
    compiler=ROOT/'.tools/bin/luac'
    if not compiler.exists(): raise ValueError('缺少 Lua 语法校验工具')
    with tempfile.NamedTemporaryFile(suffix='.lua') as f:
        f.write(code.encode());f.flush()
        result=subprocess.run([str(compiler),'-p',f.name],capture_output=True,text=True,timeout=3)
    if result.returncode: raise ValueError('Lua 语法错误：'+result.stderr[-500:])
    return package
