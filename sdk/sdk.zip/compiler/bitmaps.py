"""Bounded RGB565 indexed sprites; v2 adds 256 colours and palette alpha."""
import re
import base64
import zlib
from .game_contract import LIMITS, BITMAP_V2, limits_for

ENCODING = 'indexed8-zlib'

def is_wide(bitmap):
    return 'alpha' in bitmap or bitmap.get('encoding') == ENCODING

def unpack(bitmap):
    """Decode one bounded zlib stream; never inflate an unbounded payload."""
    if 'encoding' not in bitmap:
        return bitmap
    if set(bitmap) != {'width', 'height', 'encoding', 'data'} or bitmap['encoding'] != ENCODING:
        raise ValueError('位图压缩格式无效')
    w, h = bitmap['width'], bitmap['height']
    if type(w) is not int or type(h) is not int or not 1 <= w <= BITMAP_V2['width'] or not 1 <= h <= BITMAP_V2['height']:
        raise ValueError('位图尺寸超出格式限制')
    expected = 640 + w*h
    data = bitmap['data']
    if not isinstance(data, str) or not 0 < len(data) <= ((expected+128+2)//3)*4:
        raise ValueError('位图压缩数据长度无效')
    try:
        compressed = base64.b64decode(data, validate=True)
        if base64.b64encode(compressed).decode() != data:
            raise ValueError('noncanonical base64')
        decoder = zlib.decompressobj()
        raw = decoder.decompress(compressed, expected+1)
        if len(raw) != expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
            raise ValueError('invalid bitmap zlib size/stream')
    except (ValueError, zlib.error) as error:
        raise ValueError('位图压缩数据损坏') from error
    if raw[512] >> 4:
        raise ValueError('位图索引0必须透明')
    return {'width': w, 'height': h, 'palette': raw[:512].hex(),
            'alpha': raw[512:640].hex(), 'pixels': raw[640:].hex()}

def pack(bitmap):
    """Lossless, deterministic storage encoding; authoring pixels stay intact."""
    normalize([bitmap])
    if 'alpha' not in bitmap:
        return bitmap
    raw = bytes.fromhex(bitmap['palette'] + bitmap['alpha'] + bitmap['pixels'])
    return {'width': bitmap['width'], 'height': bitmap['height'], 'encoding': ENCODING,
            'data': base64.b64encode(zlib.compress(raw, 9)).decode()}

def normalize(bitmaps, *, runtime_profile='legacy'):
    limits=limits_for(runtime_profile)
    if not isinstance(bitmaps,list) or not 1<=len(bitmaps)<=limits['bitmap_count']:
        raise ValueError(f"位图数量必须为1–{limits['bitmap_count']}")
    total=0;wide=False
    for b in bitmaps:
        if isinstance(b,dict):b=unpack(b)
        if not isinstance(b,dict) or set(b) not in ({'width','height','palette','pixels'},{'width','height','palette','pixels','alpha'}):
            raise ValueError('位图字段无效')
        hd='alpha' in b;wide|=hd
        w,h=b['width'],b['height']
        if type(w) is not int or type(h) is not int or not 1<=w<=(BITMAP_V2['width'] if hd else LIMITS['bitmap_width']) or not 1<=h<=(BITMAP_V2['height'] if hd else LIMITS['bitmap_height']):
            raise ValueError('位图尺寸超出格式限制')
        if not isinstance(b['palette'],str) or not re.fullmatch('[0-9a-f]{'+str(1024 if hd else 64)+'}',b['palette']):
            raise ValueError('位图调色板无效')
        if hd and (not isinstance(b['alpha'],str) or not re.fullmatch('0[0-9a-f]{255}',b['alpha'])):
            raise ValueError('位图透明度必须为256个十六进制等级，索引0透明')
        if not isinstance(b['pixels'],str) or len(b['pixels'])!=w*h*(2 if hd else 1) or not re.fullmatch('[0-9a-f]+',b['pixels']):
            raise ValueError('位图像素长度或索引无效')
        total+=w*h
    limit=limits['bitmap_pixels'] if runtime_profile=='resources-v2' else BITMAP_V2['pixels'] if wide else LIMITS['bitmap_pixels']
    if total>limit:raise ValueError(f"位图像素总数超过{limit}")
    if runtime_profile=='resources-v2':
        # Four 32-bit fields match offsetof(EdgeBitmap, palette) on both ABIs.
        decoded=sum(b['width']*b['height']+(768 if is_wide(b) else 32)+16 for b in bitmaps)
        if decoded>limits['asset_bytes']:raise ValueError('解码位图内存超过资源预算')
    return bitmaps
