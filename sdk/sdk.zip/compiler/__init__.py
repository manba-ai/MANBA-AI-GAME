"""Local game package compiler and validation helpers."""
