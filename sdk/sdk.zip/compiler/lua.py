"""Lossless lexical packing for authored Lua within the device's code limit."""
import re

_TOKEN = re.compile(r"(?P<longcomment>--\[(?P<ceq>=*)\[.*?\](?P=ceq)\])|--[^\n]*|(?P<long>\[(?P<eq>=*)\[.*?\](?P=eq)\])|'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"|(?:0[xX][0-9a-fA-F]+(?:\.[0-9a-fA-F]+)?(?:[pP][+-]?\d+)?|(?:\d+\.(?!\.)\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?)|[A-Za-z_][A-Za-z_0-9]*|\.\.\.|\.\.|//|<<|>>|<=|>=|==|~=|\S", re.S)

def compact(source):
    """Keep literals byte-for-byte; only remove comments and redundant space."""
    tokens = [m.group() for m in _TOKEN.finditer(source) if not m.group().startswith('--')]
    out = []
    previous = ''
    for token in tokens:
        if previous:
            joined = previous + token
            # Retokenizing the join catches number/concat and operator ambiguity.
            numeric=previous[0].isdigit() or previous.startswith('.') and len(previous)>1 and previous[1].isdigit()
            if (previous[-1].isalnum() or previous[-1]=='_') and (token[0].isalnum() or token[0]=='_') or numeric and token.startswith('.') or previous=='[' and token.startswith('[') or [m.group() for m in _TOKEN.finditer(joined)] != [previous, token]:
                out.append(' ')
        out.append(token)
        previous = token
    return ''.join(out)
