"""Bounded game audio schemas and lossless PCM encoding."""
import base64
import struct
import zlib
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, StrictInt, model_validator

class Strict(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)

Wave=Literal['pulse','triangle','noise','sine','saw']
class Effect(Strict):
    id:str=Field(pattern=r'^[a-z][a-z0-9_]{0,23}$')
    wave:Wave='pulse'
    frequency:float=Field(default=440,ge=40,le=4000)
    end_frequency:float=Field(default=440,ge=40,le=4000)
    duration_ms:StrictInt=Field(default=120,ge=20,le=2000)
    volume:float=Field(default=.35,ge=0,le=.7)
    duty:float=Field(default=.5,ge=.125,le=.75)

class PCM(Strict):
    format:Literal['pcm-s16le','pcm-s16le-delta-zlib']='pcm-s16le'
    sample_rate:Literal[16000]=16000
    frames:StrictInt=Field(ge=1,le=128000)
    chunks:list[str]=Field(min_length=1,max_length=128)
    @model_validator(mode='after')
    def check(self):
        size=0; parts=[]
        for chunk in self.chunks:
            if not 4<=len(chunk)<=4096:raise ValueError('PCM 块必须为 4–4096 个 Base64 字符')
            raw=base64.b64decode(chunk,validate=True)
            if base64.b64encode(raw).decode()!=chunk or (self.format=='pcm-s16le' and len(raw)%2):raise ValueError('PCM 块编码或采样边界无效')
            size+=len(raw)
            if size>self.frames*2+1024:raise ValueError('PCM 压缩输入超出上限')
            parts.append(raw)
        decode_pcm(self.model_dump(), encoded=b''.join(parts))
        return self

def decode_pcm(sample, *, encoded=None):
    """Decode once at load; output is bit-identical signed PCM16, including silence."""
    raw=encoded if encoded is not None else b''.join(base64.b64decode(c,validate=True) for c in sample['chunks'])
    expected=sample['frames']*2
    if sample['format']=='pcm-s16le-delta-zlib':
        if len(raw)>expected+1024:raise ValueError('PCM 压缩输入超出上限')
        decoder=zlib.decompressobj()
        try:raw=decoder.decompress(raw,expected+1)
        except zlib.error as exc:raise ValueError('PCM 压缩流无效') from exc
        if len(raw)!=expected or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
            raise ValueError('PCM 压缩流长度或结束标记无效')
        result=bytearray(expected); previous=0
        for i,(delta,) in enumerate(struct.iter_unpack('<H',raw)):
            previous=(previous+delta)&65535
            struct.pack_into('<H',result,i*2,previous)
        raw=bytes(result)
    if len(raw)!=expected:raise ValueError('PCM 数据长度与采样数不一致')
    return raw

def compress_pcm(raw):
    values=struct.unpack('<%dH'%(len(raw)//2),raw)
    delta=struct.pack('<%dH'%len(values),*[(v-(values[i-1] if i else 0))&65535 for i,v in enumerate(values)])
    compressed=zlib.compress(delta,9)
    return {'format':'pcm-s16le-delta-zlib','sample_rate':16000,'frames':len(values),
            'chunks':[base64.b64encode(compressed[i:i+3072]).decode() for i in range(0,len(compressed),3072)]}

class SampleEffect(Strict):
    id:str=Field(pattern=r'^[a-z][a-z0-9_]{0,23}$')
    sample:PCM
    volume:float=Field(default=1,ge=0,le=1)

class Track(Strict):
    wave:Wave='triangle'
    volume:float=Field(default=.2,ge=0,le=.5)
    notes:list[tuple[StrictInt,StrictInt]]=Field(min_length=1,max_length=64)
    @model_validator(mode='after')
    def check(self):
        for midi,ticks in self.notes:
            if midi!=0 and not 36<=midi<=95:raise ValueError('音符为MIDI 36..95，0表示休止')
            if not 1<=ticks<=16:raise ValueError('音长为1..16个十六分音符')
        return self

class Music(Strict):
    bpm:StrictInt=Field(default=120,ge=60,le=200)
    tracks:list[Track]=Field(min_length=1,max_length=4)
    @model_validator(mode='after')
    def check(self):
        lengths=[sum(n[1] for n in t.notes) for t in self.tracks]
        if len(set(lengths))!=1:raise ValueError('音乐各轨道的总音长必须一致')
        if lengths[0]*15/self.bpm>32:raise ValueError('循环音乐最多32秒')
        return self

class AudioSpec(Strict):
    effects:list[Effect|SampleEffect]=Field(default_factory=list,max_length=12)
    music:Music|None=None
    @model_validator(mode='after')
    def check(self):
        if len({e.id for e in self.effects})!=len(self.effects):raise ValueError('音效ID重复')
        if any(e.id=='music' for e in self.effects):raise ValueError('music是保留音频名称')
        if sum(e.sample.frames for e in self.effects if isinstance(e,SampleEffect))>192000:
            raise ValueError('录音采样总量最多 192000 帧（384000 字节）')
        return self

def normalize(value):
    return AudioSpec.model_validate(value).model_dump(mode='json',exclude_none=True)

def has_samples(bank):
    return bool(bank and any('sample' in e for e in bank.get('effects',[])))

def has_compressed_samples(bank):
    return bool(bank and any(e.get('sample',{}).get('format')=='pcm-s16le-delta-zlib' for e in bank.get('effects',[])))

def lua_metadata(bank):
    # Large recordings live in assets only, outside the Lua memory/source cap.
    if not has_samples(bank):return bank
    return {'effects':[{'id':e['id']} for e in bank['effects']],
            **({'music':True} if bank.get('music') else {})}

