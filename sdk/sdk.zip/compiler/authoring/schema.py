"""The custom game contract: JSON metadata + source + declarative assertions."""
import json
import math
from typing import Literal,Annotated
from pydantic import BaseModel,ConfigDict,Field,StrictInt,model_validator
from ..packages import validate,lua_value
from ..audio import AudioSpec
from ..game_contract import PROFILE,LIMITS
from ..cover_art import CoverHD

KEYS=('up','down','left','right','action','pause','restart','stop','a','b','x','y')
class Strict(BaseModel):
    model_config=ConfigDict(extra='forbid')
Key=Literal['up','down','left','right','action','pause','restart','stop','a','b','x','y']
class InputAction(Strict):
    kind:Literal['input']
    value:Key
    count:Literal[1]=1
class ButtonAction(Strict):
    kind:Literal['buttons']
    value:StrictInt=Field(ge=0,le=31)
    count:Literal[1]=1
class StepAction(Strict):
    kind:Literal['step']
    value:StrictInt=Field(ge=0,le=LIMITS['step_ms'])
    count:StrictInt=Field(default=1,ge=1,le=200)
Action=Annotated[InputAction|ButtonAction|StepAction,Field(discriminator='kind')]
class Expect(Strict):
    path:str=Field(pattern=r'^[a-zA-Z_][a-zA-Z_0-9]*(\.[a-zA-Z_][a-zA-Z_0-9]*){0,3}$',max_length=80)
    op:Literal['eq','gt','gte','lt','lte']='eq'
    value:str|int|float|bool
    @model_validator(mode='after')
    def finite(self):
        if isinstance(self.value,float) and not math.isfinite(self.value):raise ValueError('expected value must be finite')
        return self
class Case(Strict):
    name:str=Field(min_length=1,max_length=80)
    actions:list[Action]=Field(max_length=20)
    expect:list[Expect]=Field(min_length=1,max_length=8)
    rule_ids:list[StrictInt]|None=Field(default=None,max_length=12)
class TestChange(Strict):
    case:str=Field(min_length=1,max_length=80)
    rule_id:StrictInt=Field(ge=1,le=12)
    reason:str=Field(min_length=8,max_length=300)
class ControlBinding(Strict):
    label:str=Field(min_length=1,max_length=40)
    key:Key
    hold:Literal['up','down','left','right','action']|None=None
    repeat_ms:Literal[0,120,180]=0
class Controller(Strict):
    version:Literal[1]=1
    layout:Literal['switch','xbox']='xbox'
    bindings:dict[Literal['up','down','left','right','a','b','x','y'],ControlBinding]
    primary:Literal['a','b','x','y']='a'
    hint:str=Field(max_length=300)
    diagonal:bool=False
class UI(Strict):
    input_mode:Literal['events','held']='events'
    system:Literal['game-hud-v1']|None=None
    controls:dict[Key,Annotated[str,Field(max_length=60)]]
    controller:Controller|None=None
    @model_validator(mode='after')
    def check(self):
        if set(self.controls)-set(KEYS) or len(self.controls)>12 or any(len(v)>60 for v in self.controls.values()):raise ValueError('invalid controls')
        return self
class Viewport(Strict):
    width:Literal[320]=320
    height:Literal[240]=240

class LauncherIcon(Strict):
    width:Literal[80]=80
    height:Literal[80]=80
    encoding:Literal['indexed8-zlib']='indexed8-zlib'
    data:str=Field(min_length=4,max_length=9560)
    @model_validator(mode='after')
    def check(self):
        from ..packages import validate_launcher_icon
        validate_launcher_icon(self.model_dump())
        return self

class GameSpec(Strict):
    cover:CoverHD|None=None
    launcher_icon:LauncherIcon|None=None
    records_id:str|None=Field(default=None,min_length=1,max_length=64,pattern=r'^[a-zA-Z0-9_.-]+$')
    name:str=Field(min_length=1,max_length=24)
    description:str=Field(min_length=1,max_length=1200)
    rules:list[str]=Field(min_length=1,max_length=12)
    ui:UI
    # Readable authoring source may be larger than the packed device payload.
    # build() enforces 128 KiB legacy / 256 KiB resources-v2 compiled code.
    code:str=Field(min_length=1,max_length=300000)
    tests:list[Case]=Field(min_length=1,max_length=6)
    test_changes:list[TestChange]|None=Field(default=None,max_length=6)
    audio:AudioSpec|None=None
    # Every generated package uses the same 320x240 canvas.
    viewport:Viewport|None=Field(default_factory=Viewport)
    data:dict|None=None
    bitmaps:list[dict]|None=None
    bitmap_compression:Literal['none','zlib']='none'
    runtime_profile:Literal['legacy','resources-v2']='legacy'
    sprite_manifest:dict|None=None
    requires:list[Literal['bitmap-scale-v1','bitmap-column-v1','rumble-v1','graphics-v2']]=Field(default_factory=list,max_length=4)
    @model_validator(mode='after')
    def check(self):
        if self.viewport is None:
            # Migrate specs saved before the single-target display contract.
            self.viewport=Viewport()
        if self.bitmaps is not None:
            from ..bitmaps import normalize
            normalize(self.bitmaps,runtime_profile=self.runtime_profile)
        if self.sprite_manifest is not None:
            from ..assets import bind_manifest
            self.data=bind_manifest(self.sprite_manifest,self.bitmaps,self.data,self.code,runtime_profile=self.runtime_profile)
        if self.data is not None:
            def check_data(value,depth=0):
                if depth>16:raise ValueError('游戏数据层级超过16层')
                if isinstance(value,dict):
                    if any(not isinstance(k,str) for k in value):raise ValueError('游戏数据键必须为文本')
                    for v in value.values():check_data(v,depth+1)
                elif isinstance(value,list):
                    for v in value:check_data(v,depth+1)
                elif not isinstance(value,(str,bool,int,float)) or isinstance(value,float) and not math.isfinite(value):
                    raise ValueError('游戏数据只支持对象、数组、文本、布尔和有限数字')
            check_data(self.data)
            if len(json.dumps(self.data,ensure_ascii=False).encode())>49152:raise ValueError('游戏数据超过48 KiB')
        if any(len(r)>300 for r in self.rules):raise ValueError('rule too long')
        if len({t.name for t in self.tests})!=len(self.tests):raise ValueError('验收用例名称不能重复')
        for case in self.tests:
            if case.rule_ids is not None and (not case.rule_ids or len(set(case.rule_ids))!=len(case.rule_ids) or any(i<1 or i>len(self.rules) for i in case.rule_ids)):
                raise ValueError('rule_ids 必须引用存在的规则编号')
        for change in self.test_changes or []:
            # A changed case may refer to a rule from the previous version.
            if change.case in {t.name for t in self.tests} and change.rule_id>len(self.rules):raise ValueError('test_changes 必须引用对应规则')
        if len({c.case for c in self.test_changes or []})!=len(self.test_changes or []):raise ValueError('test_changes 用例不能重复')
        if sum(a.count for t in self.tests for a in t.actions)>1200:raise ValueError('test budget exceeds 1200 steps')
        if any(a.kind=='buttons' for t in self.tests for a in t.actions) and self.ui.input_mode!='held':raise ValueError('buttons tests require held mode')
        return self

PREFIX='''
-- Trusted SDK adapter: capture the same drawing calls for computer/device views.
print=nil;warn=nil;pcall=nil;xpcall=nil;load=nil;dofile=nil;loadfile=nil;collectgarbage=nil
local native=screen
local frame={}
local cover_visible=false
local insert=table.insert
local floor,min,max=math.floor,math.min,math.max
local width,height={CANVAS_WIDTH},cfg.viewport.height
local function finite(v) assert(type(v)=='number' and v==v and v>-math.huge and v<math.huge,'non-finite drawing coordinate');return v end
local function record(v) if native.capture==false then return end;if #frame>={DRAW_LIMIT} then error('draw exceeds {DRAW_LIMIT} commands') end;insert(frame,v) end

screen={}
function screen.clear(c) native.clear(c);if native.capture~=false then record({'c',c}) end end
function screen.rect(x,y,w,h,c)
 finite(x);finite(y);finite(w);finite(h)
 local x0=max(0,floor(x));local y0=max(0,floor(y))
 local x1=min(width,floor(x+w));local y1=min(height,floor(y+h))
 if x1<=x0 or y1<=y0 then return end

 native.rect(x0,y0,x1-x0,y1-y0,c);if native.capture~=false then record({'r',x0,y0,x1-x0,y1-y0,c}) end
end
function screen.text(x,y,t,c,s) s=s or 1;native.text(x,y,t,c,s);if native.capture~=false then record({'t',x,y,t,c,s}) end end
'''
SUFFIX='''
local userDraw,userSnapshot=draw,snapshot
assert(type(init)=='function' and type(input)=='function' and type(update)=='function' and type(userDraw)=='function' and type(userSnapshot)=='function','missing SDK callbacks')
function draw() frame={};cover_visible=false;userDraw(); end
function snapshot() local s=userSnapshot();assert(type(s)=='table','snapshot must return table');s.engine='custom';s.scene=frame;if cfg.viewport then s.viewport=cfg.viewport end;return s end
'''
def _assemble(spec, data):
    """Assemble authored Lua, compiled assets and the SDK adapters."""
    ui=data['ui']
    cfg={'engine':'custom','name':spec.name,'ui':ui,'viewport':data['viewport']}
    bitmaps=data.get('bitmaps')
    cover=None
    if spec.cover is not None:
        from ..cover_art import compile_art
        bitmaps,cover=compile_art(spec.cover,bitmaps or [],runtime_profile=spec.runtime_profile)
    data_source='local game_data='+lua_value(data['data'])+'\n' if spec.data is not None else ''
    # Keep the authored Lua and SDK adapters within the package code budget.
    from ..records import integration
    record_meta, record_source = integration(data)
    authored=spec.code+'\n'+record_source
    if cover:
        from ..cover_art import lua_source
        authored+=lua_source(cover)
    compact='\n'.join(line for line in authored.splitlines()
                      if line.strip() and not line.lstrip().startswith('--'))
    if spec.code.startswith('-- @library-controller-v2\n'):
        from ..lua import compact as pack_authored
        compact=pack_authored(authored)
    prefix=PREFIX.replace('{CANVAS_WIDTH}',str(PROFILE['viewport']['width'])).replace('{DRAW_LIMIT}',str(LIMITS['draw_commands']))
    suffix=SUFFIX
    source='cfg='+lua_value(cfg)+'\n'+prefix+'\ndo\n'+data_source+compact+'\nend\n'+suffix
    has_bitmaps=bitmaps is not None
    if has_bitmaps:
        adapter="""
function screen.sprite(id,x,y,flip,w,h)
 x=floor(finite(x));y=floor(finite(y));flip=flip==true
 if w~=nil or h~=nil then
  assert(w~=nil and h~=nil,'scaled sprite needs width and height')
  w=floor(finite(w));h=floor(finite(h))
  native.sprite(id,x,y,flip,w,h);if native.capture~=false then record({'s',id,x,y,flip,w,h}) end
 else native.sprite(id,x,y,flip);if native.capture~=false then record({'s',id,x,y,flip}) end end
end
function screen.column(id,x,y,h,u,light,clip)
 x=floor(finite(x));y=floor(finite(y));h=floor(finite(h))
 u=floor(finite(u));light=floor(finite(light));clip=floor(finite(clip))
 native.column(id,x,y,h,u,light,clip)
 if native.capture==false then return end
 local entry=frame[#frame]
 if not entry or entry[1]~='V' or #entry[2]>385 then entry={'V',{}};record(entry) end
 local columns=entry[2];local n=#columns
 columns[n+1]=id;columns[n+2]=x;columns[n+3]=y;columns[n+4]=h
 columns[n+5]=u;columns[n+6]=light;columns[n+7]=clip
end
"""
        source=source.replace(prefix,prefix+adapter,1)
    if 'graphics-v2' in spec.requires:
        from ..packages import ROOT
        graphics=(ROOT/'games/library/graphics-v2.lua').read_text()
        source=source.replace('\ndo\n'+data_source,'\n'+graphics+'\ndo\n'+data_source,1)
    if spec.audio is not None:
        from ..packages import ROOT
        from ..audio import lua_metadata
        # Explicit opt-in preserves existing immutable game package bytes.
        lifecycle_v2=any(line.strip()=='-- @audio-lifecycle-v2' for line in spec.code.splitlines())
        wrapper='audio-lifecycle-v2.lua' if lifecycle_v2 else 'audio.lua'
        source+='\ndo\nlocal AUDIO='+lua_value(lua_metadata(data['audio']))+'\n'+(ROOT/'games'/wrapper).read_text()+'\nend\n'
    if spec.code.startswith('-- @library-controller-v2\n'):
        # Pack the complete code, including fixed SDK and audio adapters.
        source=pack_authored(source)
    package={'format':'edge.game/1','sdk':1,'engine':'custom','name':spec.name,'config':cfg,
             'ui':ui,'description':spec.description,'rules':spec.rules,'assets':{},'code':source,
             'requires':['buttons-v1'] if ui['input_mode']=='held' else []}
    package['requires'].extend(spec.requires)
    if spec.runtime_profile!='legacy':
        package['runtime_profile']=spec.runtime_profile
        package['requires'].append(spec.runtime_profile)
    package['records']=record_meta
    package['requires'].append('records-v1')
    package['requires'].append('viewport-320x240-v1')
    if spec.ui.controller is not None:package['requires'].append('abxy-v1')
    if spec.audio is not None:
        package['assets']['audio']=data['audio'];package['requires'].append('audio-v1')
        from ..audio import has_samples,has_compressed_samples
        if has_samples(data['audio']):package['requires'].append('audio-pcm-v1')
        if has_compressed_samples(data['audio']):package['requires'].append('audio-pcm-zlib-v1')
    if bitmaps is not None:
        from ..bitmaps import is_wide,pack,ENCODING
        if spec.bitmap_compression=='zlib':bitmaps=[pack(b) for b in bitmaps]
        package['assets']['bitmaps']=bitmaps;package['requires'].append('bitmap-v1')
        if any(is_wide(b) for b in bitmaps):package['requires'].append('bitmap-indexed8-v2')
        if any(b.get('encoding')==ENCODING for b in bitmaps):package['requires'].append('bitmap-zlib-v1')
    if cover:
        package['assets']['cover']=cover
        if 'bitmap-scale-v1' not in package['requires']:package['requires'].append('bitmap-scale-v1')
    return package


def build(spec):
    spec=GameSpec.model_validate(spec)
    data=spec.model_dump(mode='json',exclude_none=True)
    if spec.launcher_icon is None:
        raise ValueError('缺少游戏图标：构建时添加 --icon 指定不透明的正方形 PNG，编译尺寸为 80×80')
    package=_assemble(spec,data)
    package['assets']['launcher_icon']=data['launcher_icon']
    validate(package,installable=True)
    return package,data
