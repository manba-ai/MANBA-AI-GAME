"""Execute untrusted game code only in the restricted native Lua runner."""
import json
import hashlib
import os
import selectors
import subprocess
import tempfile
import time
from pathlib import Path
from ..packages import ROOT,encode
from ..game_contract import provenance,CONTRACT_SHA256
from ..diagnostics import DiagnosticError,diagnostic_for

class GameError(DiagnosticError):
    def __init__(self,message,**details):
        classified=diagnostic_for(ValueError(message),stage='runtime')
        super().__init__(message,code=details.pop('code',classified['code']),stage=details.pop('stage',classified['stage']),**details)

class Session:
    def __init__(self, code):
        self.process = None
        self.assets_file = None
        self.selector = selectors.DefaultSelector()
        self.buffer = b''
        self.file = tempfile.NamedTemporaryFile(suffix='.lua')
        try:
            args=[str(ROOT/'.tools/bin/game-runner'), self.file.name]
            if isinstance(code,dict):
                runtime_profile=code.get('runtime_profile','legacy')
                from ..game_contract import limits_for
                limits_for(runtime_profile)
                if (runtime_profile=='resources-v2')!=('resources-v2' in code.get('requires',[])):raise ValueError('resource profile capability mismatch')
                if runtime_profile=='resources-v2':args.append('--resources-v2')
                if 'graphics-v2' in code.get('requires',[]):args.append('--graphics-v2')
                bitmaps=code.get('assets',{}).get('bitmaps');code=code['code']
                if bitmaps is not None:
                    from ..bitmaps import normalize
                    from ..packages import lua_value
                    normalize(bitmaps,runtime_profile=runtime_profile)
                    definitions='\n'.join('screen.define_bitmap('+','.join([str(i),str(b['width']),str(b['height']),lua_value(b.get('encoding',b.get('palette'))),lua_value(b.get('data',b.get('pixels')))]+([lua_value(b['alpha'])] if 'alpha' in b else []))+')' for i,b in enumerate(bitmaps,1))
                    self.assets_file=tempfile.NamedTemporaryFile(suffix='.lua')
                    self.assets_file.write(definitions.encode());self.assets_file.flush();args.append(self.assets_file.name)
            self.file.write(code.encode()); self.file.flush()
            self.process = subprocess.Popen(args,
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                env={'LANG':'C', 'PATH':'/usr/bin:/bin'}, cwd=tempfile.gettempdir(), bufsize=0)
            self.selector.register(self.process.stdout, selectors.EVENT_READ)
            self.initial = self.read()
        except Exception:
            self.close(); raise

    def read(self):
        deadline = time.monotonic() + 1.5
        while b'\n' not in self.buffer:
            left = deadline-time.monotonic()
            if left <= 0 or not self.selector.select(left):
                self.close(); raise GameError('游戏执行超时（1.5 秒），已停止进程')
            chunk = os.read(self.process.stdout.fileno(), 8192)
            if not chunk:
                self.close(); raise GameError('游戏进程退出或达到 CPU 限制')
            self.buffer += chunk
            if len(self.buffer)>40000:
                self.close(); raise GameError('游戏状态过大')
        line, self.buffer = self.buffer.split(b'\n',1)
        try:
            result = json.loads(line.decode('utf-8'))
        except (ValueError, UnicodeError):
            self.close(); raise GameError('游戏状态包含无效 JSON 或 UTF-8')
        if not result.get('ok'):
            self.close(); raise GameError(result.get('error','游戏执行失败'),callback=result.get('callback'))
        if result.get('contract_sha256')!=CONTRACT_SHA256:
            self.close();raise GameError('运行器与游戏契约不一致，请更新 SDK 运行文件',code='contract_stale',stage='runtime')
        return result

    def command(self, value):
        if not self.process or self.process.poll() is not None: raise GameError('试玩已结束，请重新试玩')
        try:
            self.process.stdin.write((value+'\n').encode())
            return self.read()
        except (BrokenPipeError,OSError) as exc:
            self.close(); raise GameError('试玩进程已停止') from exc

    def close(self):
        if self.process:
            if self.process.poll() is None: self.process.kill()
            self.process.wait()
            for pipe in (self.process.stdin,self.process.stdout):
                if pipe: pipe.close()
            self.process = None
        self.selector.close()
        self.file.close()
        if self.assets_file:self.assets_file.close()

    def __enter__(self): return self
    def __exit__(self,*args): self.close()


def validate_runtime(package,cases):
    try:return _validate_runtime(package,cases)
    except GameError as exc:
        exc.diagnostic.setdefault('artifact_sha256',hashlib.sha256(encode(package)).hexdigest())
        raise

def _validate_runtime(package, cases):
    """Lifecycle, bounded soak, and declarative game assertions. No test Lua runs."""
    started=time.perf_counter(); timings=[]; peak=0; frames=0; max_draws=0
    def observe(result):
        nonlocal peak,frames,max_draws
        g=result['game']
        if not isinstance(g,dict) or g.get('status') not in ('paused','running','won','over'):
            raise GameError('snapshot.status 必须是 paused/running/won/over')
        for key in ('ticks','score'):
            if type(g.get(key)) not in (int,float): raise GameError(f'snapshot.{key} 必须为数字')
        if not isinstance(g.get('scene'),list) or not g['scene']: raise GameError('draw 必须绘制画面')
        peak=max(peak,result['lua_peak']);max_draws=max(max_draws,result['draw_commands']);frames+=1
        return g
    def command(s,c):
        t=time.perf_counter();r=s.command(c);timings.append((time.perf_counter()-t)*1000);return observe(r)
    with Session(package) as s:
        initial=observe(s.initial)
        if initial['status']!='paused' or initial['ticks']!=0: raise GameError('init 必须暂停且 ticks=0')
        g=command(s,'key action')
        if g['status']!='running':raise GameError('空格 action 必须能从暂停开始')
        g=command(s,'step 33')
        if g['ticks']<=0:raise GameError('运行 update 必须增加 ticks')
        command(s,'key pause');before=command(s,'state');after=command(s,'step 33')
        if before!=after or after['status']!='paused':raise GameError('暂停时 update 不得改变游戏状态和画面')
        g=command(s,'key restart')
        if g['status']!='paused' or g['ticks']!=0:raise GameError('restart 必须重置并暂停')
        command(s,'key action');g=command(s,'key stop')
        if g['status']!='paused':raise GameError('stop 必须暂停')
        if 'abxy-v1' in package.get('requires',[]):
            if package.get('ui',{}).get('system')=='game-hud-v1':
                command(s,'key restart');g=command(s,'key b')
                if not g.get('exit_requested') or g['ticks']!=0:raise GameError('系统页 B 必须退出且不能开始模拟')
            for start in (('a',) if package.get('ui',{}).get('system')=='game-hud-v1' else ('a','b')):
                command(s,'key restart');g=command(s,'key '+start)
                if g['status']!='running':raise GameError('A / B 必须能开始游戏')
                for key in ('a','b','x','y'):command(s,'key '+key)
                command(s,'key stop')
        for i in range(420):
            if i%70==0:command(s,'key restart');command(s,'key action')
            if i%13==0:command(s,'key '+('up','down','left','right','action')[(i//13)%5])
            if 'buttons-v1' in package.get('requires',[]) and i%4==0:command(s,'buttons '+str((0,1,2,4,8,16,17,24)[(i//4)%8]))
            command(s,'step 33')
    passed=['生命周期：开始 / 暂停 / 重置 / 失焦停止','420 帧输入与资源检查']
    if 'abxy-v1' in package.get('requires',[]):passed.append('ABXY：A 开始与四键动作运行检查' if package.get('ui',{}).get('system')=='game-hud-v1' else 'ABXY：A/B 开始与四键动作运行检查')
    def test_value(g,path):
        for part in path.split('.'):
            if not isinstance(g,dict) or part not in g:return '<missing>'
            g=g[part]
        return g
    def check_case(case):
        with Session(package) as s:
            g=observe(s.initial)
            paths=list(dict.fromkeys(['status','ticks']+[e['path'] for e in case['expect']]))
            def values():return ','.join(f"{p}={test_value(g,p)!r}" for p in paths)[:220]
            trace=['init: '+values()]
            for action in case['actions']:
                if action['kind']=='step':
                    for _ in range(action['count']):g=command(s,'step '+str(action['value']))
                else:g=command(s,('key ' if action['kind']=='input' else 'buttons ')+str(action['value']))
                trace.append(f"{action['kind']}({action['value']}) x{action['count']}: "+values())
            errors=[];details=[]
            for expected in case['expect']:
                value=test_value(g,expected['path']);target=expected['value'];op=expected['op']
                try:ok={'eq':lambda:value==target,'gt':lambda:value>target,'gte':lambda:value>=target,'lt':lambda:value<target,'lte':lambda:value<=target}[op]()
                except TypeError:ok=False
                if not ok:
                    errors.append(f"{expected['path']}={value!r}, expected {op} {target!r}")
                    details.append({'path':expected['path'],'actual':value,'expected':{'op':op,'value':target}})
            if errors:raise GameError(case['name']+': '+'; '.join(errors)+'。轨迹：'+'; '.join(trace)[-650:],code='assertion_failed',stage='acceptance',case=case['name'],rule_ids=case.get('rule_ids'),assertions=details,trace=trace[-21:])
    failures=[]
    for case in cases:
        try:check_case(case)
        except GameError as exc:failures.append(exc)
        else:passed.append(case['name'])
    if failures:raise GameError('；\n'.join(str(e)[:850] for e in failures)+'\n每条用例都从新的 init 暂停状态开始；必须修正所有失败行为，不能删除或弱化断言。',code='acceptance_failed',stage='acceptance',failures=[e.diagnostic for e in failures],resource_usage={'lua_peak_bytes':peak,'max_draw_commands':max_draws})
    timings.sort()
    return {'passed':passed,'frames':frames,'lua_peak_bytes':peak,'max_draw_commands':max_draws,'provenance':provenance(),
            'host_step_p95_ms':round(timings[int((len(timings)-1)*.95)],3),
            'duration_ms':round((time.perf_counter()-started)*1000,1),
            'scope':'电脑 Lua 检查；不代表设备帧率，也不保证所有玩法正确'}
