-- AUDIO contains validated, bounded data; the native bridge accepts only IDs.
local emit=audio.emit
local effects,last={},{}
for i,e in ipairs(AUDIO.effects) do effects[e.id]=i-1 end
local clock,started,previous=0,false,'paused'
audio={}
function audio.play(id)
 local index=effects[id];assert(index~=nil,'unknown audio effect: '..tostring(id))
 if clock-(last[id] or -1000)<80 then return false end
 last[id]=clock;emit(0,index);return true
end
local function optional(id) if effects[id]~=nil then audio.play(id) end end
local originalInit,originalInput,originalUpdate=init,input,update
local function sync()
 local status=type(audio_status)=='function' and audio_status() or snapshot().status
 if status==previous then return end
 if status=='running' then
  if AUDIO.music then emit(started and 4 or 1,0) end
  if not started then optional('start') end;started=true
 elseif status=='won' or status=='over' then emit(2,0);optional(status=='won' and 'win' or 'lose')
 elseif status=='paused' then emit(3,0) end
 previous=status
end
function init() emit(2,0);clock=0;last={};started=false;previous='paused';originalInit() end
function input(key)
 if key=='restart' then emit(2,0);started=false;previous='paused';last={} end
 originalInput(key);sync()
end
function update(ms)
 if previous=='running' then clock=clock+ms end
 local changed=originalUpdate(ms);sync();return changed
end
