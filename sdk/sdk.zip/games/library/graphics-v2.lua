-- Trusted graphics-v2 adapter. Device drawing never builds host scene tables.
local capture=native.capture~=false
local maps,backgrounds={},{}
function screen.sprite_region(id,x,y,sx,sy,sw,sh,flip,w,h)
 x=floor(finite(x));y=floor(finite(y));flip=flip==true
 w=w or sw;h=h or sh
 native.sprite_region(id,x,y,sx,sy,sw,sh,flip,w,h)
 if capture then record({'R',id,x,y,sx,sy,sw,sh,flip,w,h}) end
end
function screen.sprites(items)
 native.sprites(items)
 if capture and #items>0 then
  local copy={};for i,v in ipairs(items) do copy[i]={table.unpack(v)} end
  record({'B',copy})
 end
end
function screen.define_tilemap(id,bitmap,cols,rows,tw,th,cells)
 native.define_tilemap(id,bitmap,cols,rows,tw,th,cells)
 if capture then maps[id]={bitmap=bitmap,cols=cols,rows=rows,tw=tw,th=th,cells=cells} end
end
function screen.tilemap_set(id,col,row,tile)
 native.tilemap_set(id,col,row,tile)
 if capture then
  local m=maps[id];local start=(row*m.cols+col)*4
  m.cells=m.cells:sub(1,start)..string.format('%04x',tile)..m.cells:sub(start+5)
 end
end
function screen.tilemap(id,x,y)
 x=floor(finite(x));y=floor(finite(y));native.tilemap(id,x,y)
 if capture then
  local m=maps[id]
  local c0=max(0,(-x)//m.tw);local c1=min(m.cols,(width-x+m.tw-1)//m.tw)
  local r0=max(0,(-y)//m.th);local r1=min(m.rows,(height-y+m.th-1)//m.th)
  -- One compact row is <=512 bytes; even 1px tiles stay bounded to the map.
  if c1>c0 then for row=r0,r1-1 do
   local start=(row*m.cols+c0)*4
   record({'T',m.bitmap,m.tw,m.th,x+c0*m.tw,y+row*m.th,m.cells:sub(start+1,start+(c1-c0)*4)})
  end end
 end
end
function screen.background(id,revision,color,paint)
 assert(type(paint)=='function','background painter must be a function')
 if native.cache_restore(id,revision) then
  if capture then for _,v in ipairs(backgrounds[id]) do record(v) end end
 else
  -- The cache owns a complete opaque canvas, so moving objects never leave
  -- trails. Revision changes invalidate only the requested cache entry.
  local before=frame
  if capture then frame={} end
  screen.clear(color);paint();native.cache_store(id,revision)
  if capture then
   backgrounds[id]=frame;frame=before
   for _,v in ipairs(backgrounds[id]) do record(v) end
  end
 end
end
