-- The cover replaces only the initial scene; gameplay and menu state stay owned
-- by the game. The outer SDK still captures all sprites and overlay commands.
local cover_draw,cover_snapshot=draw,snapshot
local cover_hud=type(H)=='table' and type(H.phase)=='function' and type(H.paint)=='function' and type(H.begin)=='function' and H or nil
function snapshot()
 local s=cover_snapshot()
 -- The device auto-confirms games unless their initial snapshot advertises a
 -- menu. Custom cover menus need the same handshake as the shared HUD.
 -- Add this only on menu screens; full gameplay snapshots keep their budget.
 if not cover_hud and not s.exit_requested and s.menu_navigation==nil and (s.mode=='menu' or s.mode=='levels') then s.menu_navigation=true end
 return s
end
function draw()
 local s=type(hud_state)=='function' and hud_state() or cover_snapshot()
 local visible=cover_hud and cover_hud.phase(s)=='start' or not cover_hud and (s.status=='paused' and (s.ticks or 0)==0 or s.mode=='menu' or s.mode=='levels')
 local state=cover_snapshot()
 if not visible or state.pause_menu or state.mode=='pause' or state.exit_requested then cover_draw();return end
 cover_visible=true
 if cover_hud then cover_hud.begin('play') end
 screen.clear(cover_scene[1][2])
 for i=2,#cover_scene do local c=cover_scene[i];screen.sprite(c[2],c[3],c[4],false,c[6],c[7]) end
 if cover_hud then cover_hud.paint(s,'start')
 else
  -- Custom games keep their authored title, level/song selections and controls.
  -- Only their old scene geometry is suppressed over the new background.
  local clear,rect,sprite,column=screen.clear,screen.rect,screen.sprite,screen.column
  local function skip() end
  screen.clear=skip;screen.rect=skip;screen.sprite=skip;screen.column=skip
  cover_draw()
  screen.clear=clear;screen.rect=rect;screen.sprite=sprite;screen.column=column
 end
end
