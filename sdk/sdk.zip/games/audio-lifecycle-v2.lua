-- AUDIO contains validated, bounded data; the native bridge accepts only IDs.
local emit=audio.emit
local effects,last={},{}
for i,e in ipairs(AUDIO.effects) do effects[e.id]=i-1 end
local clock,started,previous=0,false,'paused'
local currentRun,finishedRun
audio={}
function audio.play(id)
 local index=effects[id];assert(index~=nil,'unknown audio effect: '..tostring(id))
 if clock-(last[id] or -1000)<80 then return false end
 last[id]=clock;emit(0,index);return true
end
local function optional(id) if effects[id]~=nil then audio.play(id) end end
local originalInit,originalInput,originalUpdate=init,input,update
local function sync()
 local status=type(audio_status)=='function' and audio_status() or snapshot().status
 local run=type(audio_run_id)=='function' and audio_run_id() or nil
 local fresh=run~=nil and run~=currentRun
 if status==previous and not fresh then return end
 if status=='running' then
  if fresh or previous=='won' or previous=='over' then
   emit(2,0);started=false;last={};finishedRun=nil
  end
  if AUDIO.music then emit(started and 4 or 1,0) end
  if not started then optional('start') end;started=true
 elseif status=='won' or status=='over' then
  emit(2,0)
  -- Result cues must follow STOP; otherwise a same-frame stop erases them.
  if run==nil or run~=finishedRun then
   optional(type(audio_result)=='function' and audio_result(status) or (status=='won' and 'win' or 'lose'))
   finishedRun=run
  end
 elseif status=='paused' then emit(3,0) end
 previous=status;currentRun=run
end
function init()
 emit(2,0);clock=0;last={};started=false;previous='paused';finishedRun=nil;originalInit()
 currentRun=type(audio_run_id)=='function' and audio_run_id() or nil
end
function input(key)
 if key=='restart' then emit(2,0);started=false;previous='paused';last={} end
 originalInput(key);sync()
end
function update(ms)
 -- Menu feedback needs a wall-clock cooldown too; gameplay state stays frozen.
 if ms>0 then clock=clock+ms end
 local changed=originalUpdate(ms);sync();return changed
end
