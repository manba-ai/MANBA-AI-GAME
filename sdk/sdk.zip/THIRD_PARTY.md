# 第三方许可

运行文件使用以下组件，完整许可见 `licenses/`：

- Lua 5.4.9：MIT，`Lua.txt`。
- Wasmoon 1.16.0：MIT，`Wasmoon.txt`。
- fflate 0.8.2：MIT，`fflate.txt`。
- ArduinoJson 7.4.2：MIT，`ArduinoJson.txt`。
- miniz 3.0.2：MIT，`miniz.txt`。
- Linux 静态运行文件包含 musl、LLVM libc++、libc++abi、libunwind 和 Zig 编译器运行支持；许可见同名文件。
