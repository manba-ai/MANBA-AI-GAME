# MANBA 手柄游戏 API

游戏画布是 320×240 RGB565，包格式为 `edge.game/1`，SDK 版本为 `1`。包和 Lua 限制见 [目标契约](../contracts/km013-st7789-i8080-v1.json)。

性能预算、压力场景与测量命令见 [游戏性能指南](GAME_PERFORMANCE_GUIDE.md)。其中建议预算不修改目标契约的硬限制。

新建和重制游戏执行 [位图素材说明](BITMAP_ASSETS.md)。清单显式使用 `encoding: "indexed8-alpha4"`，GameSpec 显式使用 `bitmap_compression: "zlib"`；兼容默认值不自动替代这两个字段。

## Lua 回调

```lua
function init() end
function input(key) end
function update(dt_ms) return false end
function draw() end
function snapshot() return {} end
```

`input` 使用 `up/down/left/right/action/a/b/x/y/pause/restart/stop`；带 `buttons-v1` 的游戏可实现 `buttons(mask)`，位 1/2/4/8/16 分别表示上/下/左/右/动作。`stop` 必须暂停并清除持续输入。`update` 的单次时间步不超过 50 ms。

需要在暂停状态操作标题、章节或结算菜单时，`snapshot()` 可以返回 `menu_navigation=true`。
网页播放器会启用已配置的导航键，菜单只发送按键事件，避免与持续按键掩码重复触发；普通暂停游戏的行为保持不变。

## 绘图

```lua
screen.clear(color565)
screen.rect(x, y, width, height, color565)
screen.text(x, y, "SCORE 10", color565, 1) -- size 1..4
```

矩形坐标会取整并裁剪到 `0..319`、`0..239`；文字坐标和文字边界必须保持在画布内，越界会使当前帧校验失败。每帧最多 300 条场景指令；网页试玩记录同一组 `scene` 指令。字体是设备内置 5×7 ASCII；中文应由网页显示。

位图使用 `screen.sprite(id,x,y,flip[,width,height])` 绘制；新旧格式共用 API，按最近邻采样。透明边缘来自素材覆盖率，无需额外 Lua 绘图。打包加载调用 `screen.define_bitmap(id,w,h,palette,pixels[,alpha])`，仅可在加载阶段定义；`alpha` 是新格式的 256 字符透明度表。

 `bitmap-zlib-v1` 支持按图无损压缩。GameSpec 设置 `bitmap_compression: "zlib"` 后，打包器将 indexed8 素材编码成 `indexed8-zlib`；源素材仍可编辑。加载器调用 `screen.define_bitmap(id,w,h,"indexed8-zlib",data)`，只在加载时解压一次。运行时图集、绘图 API、颜色与透明度不变；旧格式继续兼容。压缩缩小包体与传输量，不降低常驻图集内存。

## 自定义游戏

`compiler/authoring/schema.py` 的视口固定为 `width=320,height=240`。生成器把 `viewport-320x240-v1` 放入包能力，并按需加入 `buttons-v1`、`abxy-v1`、`audio-v1`、`audio-pcm-v1`、`bitmap-v1`。这些是 SDK 内的本地 Python 模块，无需启动服务。

## 资源与图标

图片资源兼容 `bitmap-v1`；支持可选 `bitmap-indexed8-v2`（256 调色板槽位、16 级透明度、128×128 单图），格式与能力门槛见 [位图格式](BITMAP_ASSETS.md)。每个包保留无文字的 `assets.launcher_card`：32×24、透明索引加最多 15 色，优先独立美术，由独立 PNG 编译。可使用独立的 `assets.launcher_icon` 显示原生 128×96、最多 255 色、不透明背景的压缩 ICON。ICON 不进入游戏 Lua 图集，详见 [图标与启动图](BITMAP_ASSETS.md#图标与启动图)。不要把名称、类型或中文文字烘焙进图标。

## 安全与限制

Lua 只提供受限的 `base`、`math`、`table`、`string`；禁止文件、网络、进程、动态模块、`load`、`pcall`。构建时检查包大小、Lua 语法、能力声明、视口、资源和首次绘制。

