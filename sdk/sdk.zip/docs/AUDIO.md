# 游戏音频

在 GameSpec 的 `audio` 中定义音效与音乐，构建器生成包内 `assets.audio` 和对应能力声明。Play 使用本地合成器播放，点击页面后启用声音。字段以 `compiler/audio.py` 为准。

## 合成音效与音乐

音效最多 12 项，波形支持 pulse、triangle、noise、sine、saw；频率 40～4000Hz，时长 20～2000ms，音量 0～0.7。音乐 60～200 BPM、最多 4 轨，每轨最多 64 个音符；MIDI 36～95，0 表示休止，音长 1～16 个十六分音符。各轨总音长相同，循环最多 32 秒。

以下是构建后的包字段；编写 GameSpec 时填顶层 `audio`，由构建器添加 `requires`：

```json
{
  "requires": ["viewport-320x240-v1", "audio-v1"],
  "assets": {
    "audio": {
      "effects": [{"id":"jump","wave":"pulse","frequency":300,"end_frequency":450,"duration_ms":160,"volume":0.3,"duty":0.5}],
      "music": {
        "bpm": 120,
        "tracks": [{"wave":"triangle","volume":0.2,"notes":[[60,2],[64,2],[67,2]]}]
      }
    }
  }
}
```


## 包内采样

采样为 16kHz、单声道、16 位小端 PCM。每段最多 128,000 帧，总计最多 192,000 帧。规范 Base64 每块最多 4096 字符、每段最多 128 块。音效字段为 `id`、`volume`、`sample`，sample 包含 `format`、`sample_rate`、`frames`、`chunks`。

`pcm-s16le` 为原始采样。`pcm-s16le-delta-zlib` 先按 uint16 做模 65536 差分，首个前值为 0，再 zlib 压缩。解压长度必须恰为 `frames * 2`，压缩输入最多 `frames * 2 + 1024` 字节。构建器自动添加 `audio-pcm-v1`，压缩采样另加 `audio-pcm-zlib-v1`。播放前一次解码，保留原采样数和音量。

## 生命周期

在 input/update 中调用 `audio.play(id)`；draw/snapshot 不触发声音。重复事件设置冷却，暂停、退出和切换游戏时停止相应声音。点击 Play 启用音频后检查开始、暂停、继续、结算和重开。

新移植在 Lua 中增加独立一行 `-- @audio-lifecycle-v2`，构建器会选择 `games/audio-lifecycle-v2.lua`；未声明的现有游戏继续使用原 `games/audio.lua`，包字节不会因新接口改变。新版支持 `audio_status()` 返回当前状态，避免为音频同步构建完整 snapshot；`audio_run_id()` 返回每次真正开始/重试时递增的局号，暂停继续保持不变。新局会停止旧声音、重置冷却、重新播放音乐与一次 start；未定义局号钩子时仍可使用默认生命周期。新版在结束后直接重试时也会重启音乐。

`audio_result(status)` 可返回已声明的结果音效 ID，例如不同死因；SDK 先发 STOP，再发结果音，游戏逻辑不得抢先发死亡音。定义局号后，同一局在结果页暂停再恢复不会重复发结果音。未定义结果钩子时仍用 win/lose。音效冷却时钟在暂停和菜单 update 中同样推进，不改变玩法时间。接口实现见 `games/audio-lifecycle-v2.lua`。
