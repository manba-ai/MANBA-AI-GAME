# 扩展资源与 2D 绘图接口

画布为 320×240、RGB565。

## 开启与资源预算

GameSpec 中选择需要的能力，二者可以独立启用：

```json
{
  "requires": ["graphics-v2"],
  "runtime_profile": "resources-v2",
  "bitmap_compression": "zlib"
}
```

构建器将 `resources-v2` 加入包能力声明，并校验 profile、声明和预算。bitmap-pack/1 素材清单也支持
`runtime_profile: "resources-v2"`，编译后的 bindings.json 会带入该字段。
高清素材仍用 indexed8-alpha4，无损压缩只发生在存储路径；逐帧绘制时不解压。

| 资源 | 默认 legacy | resources-v2 |
| --- | ---: | ---: |
| 完整包 | 512 KiB | 2 MiB |
| 编译后的 Lua 源码 | 128 KiB | 256 KiB |
| Lua 生命周期内存，含解码临时对象 | 512 KiB | 1 MiB |
| 位图数 | 64 | 256 |
| indexed8 / 混合图集源像素 | 196,608 | 786,432 |
| 纯 indexed4 源像素 | 49,152 | 786,432 |
| 独立常驻位图内存 | 计入 Lua | 最多 1 MiB |

单图大小仍是 indexed4 64×64 / indexed8 128×128；颜色、透明度、动画、锚点
无需降低。独立位图按 `源像素 + 调色板/alpha + 16 字节头` 逐张计账，随
Lua 状态销毁释放。背景缓存另计，最多两张 320×240 RGB565，共 300 KiB。
主机 Wasm 的 2 MiB Lua 分配策略仍是主机策略；游戏预算以契约和原生运行检查为准。

以下上限没有扩大：每帧原生绘制调用 300、位图工作量 230,400、每回调
250,000 条 Lua 指令、状态快照 24 KiB。批量/图块减少调用次数，所有可见目标
像素仍逐次计入工作量（包括透明像素与重叠写入）。大地图只画视口内部分。
极密的地图或大量批次还要通过快照体积验证，不能仅凭原生绘制上限判断可用。
资源组合还需按 [性能检查](GAME_PERFORMANCE_GUIDE.md) 检查加载峰值与运行内存。

## 图形接口

```lua
-- 从图集中取一个矩形；源坐标从 0 开始。w/h 默认等于 sw/sh。
screen.sprite_region(id, x, y, sx, sy, sw, sh, flip, w, h)

-- 一次原生调用，最多 256 项；每项恰好 4 或 6 个字段。
-- 提前创建并复用列表，每帧只更新坐标，避免反复分配。
screen.sprites({{id,x,y,false}, {id2,x2,y2,true,w,h}})

-- 仅在文件顶层、init 之前定义。16 张地图，每张最多 128×128 格。
-- 图集尺寸必须能整除 tw/th。cells 每格 4 个小写十六进制字符。
-- 0 表示空；1 起按图集从左到右、从上到下编号。
screen.define_tilemap(map_id, bitmap_id, cols, rows, tw, th, cells)
screen.tilemap(map_id, screen_x, screen_y)
screen.tilemap_set(map_id, col, row, tile) -- col/row 从 0 开始

-- 缓存整个不透明背景；revision 改变时重新 clear + paint。
-- 将此调用放在动态角色/HUD 之前；不要嵌套 background。
local function paint_background() screen.tilemap(1, 0, 0) end
screen.background(1, revision, 0, paint_background)
```

地图编辑、摄像机移动、背景动画、配色或其他影响背景的状态改变时，调用者
必须更新 revision；它是整数，范围 ±(2^53−1)。缓存命中不执行 paint，因此
paint 应只绘制静态内容，不能更新游戏逻辑。缓存命中计一次 76,800 像素复制；
首次绘制按实际操作计账。原尺寸不透明/二值透明精灵有直接 RGB565 路径，缩放、
翻转、半透明继续使用相同采样与混色规则。原来的 sprite/column API 兼容。

