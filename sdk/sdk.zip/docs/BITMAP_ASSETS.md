# 位图素材与存储格式

画布为 320×240、RGB565。PNG 图集编译和组包命令按项目根目录的 `docs/AUTHORING.md` 执行；字段以 `scripts/bitmap_pack.py` 为准。

## PNG 清单

`bitmap-pack/1` 的 `sprites` 每项指定 `name`、`file` 和 `size: [宽,高]`。高清图显式设置 `encoding: "indexed8-alpha4"`；省略时使用 indexed4。

| 字段 | 用途 |
| --- | --- |
| `rect: [x,y,w,h]` | 从源图裁出矩形 |
| `cell`、`cell_size` | 按列、行及格子尺寸切图 |
| `transparent` | 保留透明通道；不透明背景设 false |
| `trim` | 裁去透明空白；动画和固定格子设 false |
| `resample` | 像素画用 nearest；插画缩小可用 lanczos |
| `pivot: [x,y]`、`role` | 锚点和素材用途 |
| `max_colors` | indexed8 的非透明颜色/透明度组合上限，1～255，默认 255 |

每帧动画保持相同画布、比例与锚点。减色属于有损量化，不自动降低已确认素材的颜色、尺寸或透明度。PNG 转 RGB565/索引色会量化颜色；无损压缩指编译后位图的存储与恢复。

编译输出 `atlas.json`、`manifest.json`、`bindings.json`、`budget.json` 和 `preview/`。构建时通过 `--bindings` 合入图集、名字、锚点和动画；GameSpec 顶层设置 `bitmap_compression: "zlib"`。

`game_data.sprites.NAME` 是名字到数字 ID 的绑定。游戏用 `screen.sprite(id,x,y,flip[,w,h])` 绘制。文字、分数和血条可直接用 `screen.text`、`screen.rect` 绘制。

## 图集格式

indexed4 使用 16 个 RGB565 调色板槽、二值透明，每像素一个十六进制字符。indexed8 使用 256 槽、16 级 alpha，每像素两个十六进制字符；两种格式的索引 0 都透明。字段校验见 `compiler/bitmaps.py`。

高清单图最多 128×128；indexed4 单图最多 64×64。图集数量、源像素和运行预算见 [扩展资源](ENGINE_V2.md) 与 [目标契约](../contracts/km013-st7789-i8080-v1.json)。

## 包内压缩

构建器将 indexed8 图转换为 `width`、`height`、`encoding: "indexed8-zlib"` 和 `data` 四个字段。`data` 是下列二进制内容经 zlib 压缩后的 Base64：

| 偏移 | 长度 | 内容 |
| --- | ---: | --- |
| 0 | 512 B | 256 个大端 RGB565 值 |
| 512 | 128 B | 256 个 4-bit alpha，先高位后低位 |
| 640 | width × height B | 逐行 8-bit 像素索引 |

解压长度必须恰为 `640 + width*height`。加载器检查尺寸、Base64、zlib 校验和、完整流和输出长度；只在加载时解压。每帧绘制仍计入目标像素工作量。

构建器按实际素材添加位图能力声明，逐张核对解压结果与编译素材一致。压缩减少包体，不减少解压后图集内存；每图常驻数据约为 `width*height + 768` 字节，另有对象及加载开销。

## 图标与启动图

`--icon` 从独立的 4:3、不透明 PNG 编译出 32×24 `launcher_card` 和 128×96 `launcher_icon`。图标不计入游戏图集，但计入包体大小。

`--title-art` 将启动插画切成原生 320×240 的六张图块，占 76,800 源像素。角色、图标和启动页按各自显示尺寸构图，避免把同一张图缩放用于全部场景。
