#!/usr/bin/env python3
"""CLI entry point for the reusable bitmap-v1 compiler."""

import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bitmap_pack import main


if __name__ == "__main__":
    raise SystemExit(main())
