"""Read-only native package profiling. No browser/device input or game mutations.

Use named action traces to make coverage explicit; default is only a smoke run.
Host timings include Lua draw/snapshot and IPC; they are NEVER device FPS.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import math
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from compiler.authoring.runtime import Session
from compiler.game_contract import LIMITS,provenance
from compiler.packages import validate


def summary(values):
    if not values:return {'count':0}
    values=sorted(values)
    def percentile(p):return values[max(0,math.ceil(len(values)*p)-1)]
    return {'count':len(values),'min':values[0],'p50':percentile(.5),'p95':percentile(.95),'max':values[-1]}


def expand_scene(scene, bitmaps):
    for command in scene:
        if not command:
            continue
        if command[0] == 'B':
            for row in command[1]:
                yield ['s', *row]
        elif command[0] == 'T':
            _, ident, tw, th, x, y, cells = command
            columns = bitmaps[ident-1]['width']//tw
            for offset in range(0, len(cells), 4):
                tile = int(cells[offset:offset+4], 16)-1
                if tile >= 0:
                    yield ['R', ident, x+offset//4*tw, y,
                           tile % columns*tw, tile//columns*th, tw, th,
                           False, tw, th]
        else:
            yield command


def scene_work(scene,bitmaps,width,height):
    # Count clipped destination pixels, including transparent pixels.
    result={'clear_rect_pixels':0,'bitmap_pixels':0,'text_cell_pixels':0,'sprites':0,'columns':0}
    def area(x,y,w,h):return max(0,min(width,x+w)-max(0,x))*max(0,min(height,y+h)-max(0,y))
    for c in expand_scene(scene,bitmaps):
        if c[0]=='c':result['clear_rect_pixels']+=width*height
        elif c[0]=='r':result['clear_rect_pixels']+=area(*c[1:5])
        elif c[0]=='s':
            _,index,x,y,flip,*size=c;bitmap=bitmaps[index-1]
            w,h=size or (bitmap['width'],bitmap['height'])
            result['bitmap_pixels']+=area(x,y,w,h);result['sprites']+=1
        elif c[0]=='R':
            _,index,x,y,sx,sy,sw,sh,flip,w,h=c
            result['bitmap_pixels']+=area(x,y,w,h);result['sprites']+=1
        elif c[0]=='t':result['text_cell_pixels']+=len(c[3])*6*8*c[5]**2
        elif c[0]=='V':
            for i in range(0,len(c[1]),7):
                _,x,y,h,u,light,clip=c[1][i:i+7]
                result['bitmap_pixels']+=max(0,min(height,y+h,clip)-max(0,y))*5;result['columns']+=1
        else:raise ValueError('Unknown scene command: '+str(c[0]))
    return result


def strings(value,path='$'):
    if isinstance(value,str):yield len(value.encode()),path
    elif isinstance(value,dict):
        for key,item in value.items():yield from strings(item,path+'.'+key)
    elif isinstance(value,list):
        for i,item in enumerate(value):yield from strings(item,f'{path}[{i}]')


def measure(package,scenarios):
    viewport=package['config']['viewport'];bitmaps=package.get('assets',{}).get('bitmaps',[])
    reports=[]
    for scenario in scenarios:
        observations=[];timings=[];phases=collections.Counter();simulated=running_steps=steps=restarts=0;failure=None
        def observe(r):
            g=r['game'];phases[g.get('mode',g['status'])]+=1
            observations.append({'lua_bytes':r['lua_bytes'],'lua_peak_bytes':r['lua_peak'],'draw_commands':r['draw_commands'],'native_bitmap_work':r.get('bitmap_work',0),'cache_bytes':r.get('cache_bytes',0),'asset_bytes':r.get('asset_bytes',0),**scene_work(g['scene'],bitmaps,viewport['width'],viewport['height'])})
        try:
            with Session(package) as session:
                observe(session.initial)
                def run(command):
                    started=time.perf_counter();r=session.command(command)
                    if command.startswith('step '):timings.append(round((time.perf_counter()-started)*1000,4))
                    observe(r);return r
                for action in scenario['actions']:
                    kind=action['kind'];value=action['value'];count=action.get('count',1)
                    if type(count)!=int or not 1<=count<=20000:raise ValueError('count must be 1..20000')
                    if kind=='step':
                        if type(value)!=int or not 0<=value<=LIMITS['step_ms']:raise ValueError('invalid step duration')
                        command='step '+str(value)
                    elif kind=='buttons':
                        if type(value)!=int or not 0<=value<=31:raise ValueError('invalid button mask')
                        command='buttons '+str(value)
                    elif kind=='input':
                        if value not in ('up','down','left','right','action','pause','restart','stop','a','b','x','y'):raise ValueError('invalid input')
                        command='key '+value
                    else:raise ValueError('Unsupported action: '+str(kind))
                    for _ in range(count):
                        r=run(command)
                        if kind=='step':
                            steps+=1;simulated+=value;running_steps+=r['game']['status']=='running'
                        if scenario.get('restart_on_over') and r['game']['status']=='over':
                            run('key action');restarts+=1
        except Exception as exc:failure=str(exc)
        metrics={key:summary([r[key] for r in observations]) for key in observations[0]} if observations else {}
        reports.append({'name':scenario['name'],'error':failure,'metrics':metrics,'host_step_roundtrip_ms':summary(timings),'observations':len(observations),'step_calls':steps,'requested_simulated_ms':simulated,'running_step_results':running_steps,'automatic_restarts':restarts,'phase_samples':dict(phases)})
    return reports


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package',type=Path);parser.add_argument('--scenarios',type=Path);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();raw=args.package.read_bytes();package=json.loads(raw);validate(package)
    scenarios=json.loads(args.scenarios.read_text()) if args.scenarios else [{'name':'smoke only: start and 9 seconds idle','actions':[{'kind':'input','value':'action'},{'kind':'step','value':50,'count':180}]}]
    longest=max(strings(package));bank=package.get('assets',{}).get('audio',{});clips=[e['sample'] for e in bank.get('effects',[]) if 'sample' in e]
    report={'schema_version':1,'package':str(args.package.resolve()),'package_sha256':hashlib.sha256(raw).hexdigest(),'package_bytes':len(raw),'code_bytes':len(package['code'].encode()),'largest_json_string_bytes':longest[0],'largest_json_string_path':longest[1],
            'bitmap_count':len(package.get('assets',{}).get('bitmaps',[])),'bitmap_source_pixels':sum(b['width']*b['height'] for b in package.get('assets',{}).get('bitmaps',[])),
            'pcm_frames':sum(c['frames'] for c in clips),'pcm_decoded_bytes':sum(c['frames']*2 for c in clips),'pcm_base64_characters':sum(len(s) for c in clips for s in c['chunks']),
            'contract_limits':LIMITS,'provenance':provenance(),'scenario_file':str(args.scenarios.resolve()) if args.scenarios else None,
            'scenarios':measure(package,scenarios),
            'scope':'Native bounded Lua with supplied traces, draw and snapshot on every command. Host timings include IPC/serialization and exclude pixel rendering; no Play FPS claim. Pixel areas count overlapping writes repeatedly. Text is a cell-area proxy. Scenario coverage is caller-owned.'}
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    failed=[s['name'] for s in report['scenarios'] if s['error']];print(json.dumps({'report':str(args.output),'scenarios':len(scenarios),'failed':failed},ensure_ascii=False))
    if failed:raise SystemExit(1)

if __name__=='__main__':main()
