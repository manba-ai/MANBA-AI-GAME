"""Compile source art into the game's portable ``bitmap-v1`` resources.

The runtime deliberately accepts a bounded deterministic format: the contract
sets the sprite count; legacy sprites use 64x64 / 16 RGB565 palette slots; optional v2 sprites use
128x128 / 256 RGB565-and-alpha slots. This
module keeps source-art concerns (cropping, alpha cleanup, resizing and
preview PNGs) outside the game spec and emits the exact JSON consumed by the
game compiler and runtime.

Pillow is intentionally an optional tooling dependency.  Importing this
module for manifest/budget validation does not require Pillow; the compiler
prints a clear install hint only when image conversion is requested.
"""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path
from typing import Any

from compiler.game_contract import LIMITS, BITMAP_V2, limits_for
from compiler.assets import animations,bind_manifest
MAX_SPRITES = LIMITS['bitmap_count']
MAX_WIDTH = LIMITS['bitmap_width']
MAX_HEIGHT = LIMITS['bitmap_height']
MAX_PIXELS = LIMITS['bitmap_pixels']
PACKAGE_LIMIT = LIMITS['package_bytes']

NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_-]{0,47}$")
HEX16_RE = re.compile(r"^[0-9a-f]{64}$")


class BitmapPackError(ValueError):
    """A source manifest or generated pack violates the device contract."""


def _integer(value: Any, label: str, *, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise BitmapPackError(f"{label}必须是大于等于{minimum}的整数")
    return value


def _size(value: Any, label: str = "输出尺寸", *, wide: bool = False) -> tuple[int, int]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise BitmapPackError(f"{label}必须是[w,h]")
    width = _integer(value[0], f"{label}宽度", minimum=1)
    height = _integer(value[1], f"{label}高度", minimum=1)
    max_w, max_h = (BITMAP_V2["width"], BITMAP_V2["height"]) if wide else (MAX_WIDTH, MAX_HEIGHT)
    if width > max_w or height > max_h:
        raise BitmapPackError(f"{label}不能超过{max_w}×{max_h}")
    return width, height


def _source_size(value: Any, label: str) -> tuple[int, int]:
    """Validate a source atlas cell; source art may be larger than 64px."""
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise BitmapPackError(f"{label}必须是[w,h]")
    width = _integer(value[0], f"{label}宽度", minimum=1)
    height = _integer(value[1], f"{label}高度", minimum=1)
    return width, height


def _rect(value: Any, label: str = "裁剪区域") -> tuple[int, int, int, int]:
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise BitmapPackError(f"{label}必须是[x,y,w,h]")
    x = _integer(value[0], f"{label}x")
    y = _integer(value[1], f"{label}y")
    width = _integer(value[2], f"{label}宽度", minimum=1)
    height = _integer(value[3], f"{label}高度", minimum=1)
    return x, y, width, height


def validate_manifest(manifest: Any) -> dict[str, Any]:
    """Validate and return a bitmap-pack source manifest.

    A sprite can reference one shared ``source`` image with ``rect`` or
    ``cell``+``cell_size``, or provide its own ``file``.  ``size`` is always
    explicit so a large source image cannot accidentally exceed the runtime
    dimensions.
    """

    if not isinstance(manifest, dict):
        raise BitmapPackError("位图清单必须是对象")
    if manifest.get("format") != "bitmap-pack/1":
        raise BitmapPackError("位图清单 format 必须为 bitmap-pack/1")
    limits = limits_for(manifest.get("runtime_profile", "legacy"))
    sprites = manifest.get("sprites")
    if not isinstance(sprites, list) or not 1 <= len(sprites) <= limits["bitmap_count"]:
        raise BitmapPackError(f"位图清单必须包含1–{limits['bitmap_count']}个 sprites")
    if manifest.get("source") is not None and not isinstance(manifest["source"], str):
        raise BitmapPackError("共享 source 必须是文件路径")
    names: set[str] = set()
    for index, sprite in enumerate(sprites, 1):
        if not isinstance(sprite, dict):
            raise BitmapPackError(f"第{index}个 sprite 必须是对象")
        name = sprite.get("name")
        if not isinstance(name, str) or not NAME_RE.fullmatch(name):
            raise BitmapPackError(f"第{index}个 sprite 名称无效")
        if name in names:
            raise BitmapPackError(f"sprite 名称重复：{name}")
        names.add(name)
        file_path = sprite.get("file", manifest.get("source"))
        if not isinstance(file_path, str) or not file_path:
            raise BitmapPackError(f"{name}缺少 file 或共享 source")
        has_rect = "rect" in sprite
        has_cell = "cell" in sprite or "cell_size" in sprite
        if has_rect and has_cell:
            raise BitmapPackError(f"{name}不能同时使用 rect 和 cell")
        if has_rect:
            _rect(sprite["rect"])
        elif has_cell:
            if "cell" not in sprite or "cell_size" not in sprite:
                raise BitmapPackError(f"{name}的 cell 和 cell_size 必须成对出现")
            _source_size(sprite["cell_size"], f"{name} cell_size")
            cell = sprite["cell"]
            if not isinstance(cell, (list, tuple)) or len(cell) != 2:
                raise BitmapPackError(f"{name} cell 必须是[col,row]")
            _integer(cell[0], f"{name}列")
            _integer(cell[1], f"{name}行")
        elif "file" not in sprite:
            raise BitmapPackError(f"{name}需要 rect、cell 或独立 file")
        if sprite.get("encoding", "indexed4") not in ("indexed4", "indexed8-alpha4"):
            raise BitmapPackError(f"{name} encoding 无效")
        if "max_colors" in sprite:
            if sprite.get("encoding") != "indexed8-alpha4":
                raise BitmapPackError(f"{name} max_colors 仅适用于 indexed8-alpha4")
            _color_budget(sprite["max_colors"])
        _size(sprite.get("size"), f"{name} size", wide=sprite.get("encoding")=="indexed8-alpha4")
        threshold = sprite.get("alpha_threshold", 96)
        if type(threshold) is not int or not 0 <= threshold <= 255:
            raise BitmapPackError(f"{name} alpha_threshold 必须在0–255之间")
        if type(sprite.get("transparent", True)) is not bool:
            raise BitmapPackError(f"{name} transparent 必须是布尔值")
        if type(sprite.get("trim", True)) is not bool:
            raise BitmapPackError(f"{name} trim 必须是布尔值")
        if sprite.get("resample", "lanczos") not in ("lanczos", "nearest"):
            raise BitmapPackError(f"{name} resample 只能是 lanczos 或 nearest")
        if "pivot" in sprite:
            pivot = sprite["pivot"]
            if (not isinstance(pivot, (list, tuple)) or len(pivot) != 2 or
                    any(not isinstance(v, (int, float)) or isinstance(v, bool) or not math.isfinite(v)
                        for v in pivot)):
                raise BitmapPackError(f"{name} pivot 必须是有限数字[x,y]")
        if "role" in sprite and (not isinstance(sprite["role"], str) or len(sprite["role"]) > 32):
            raise BitmapPackError(f"{name} role 无效")
    try:
        animations(manifest.get('animations',{}),{sprite['name']:i for i,sprite in enumerate(sprites,1)},runtime_profile=manifest.get('runtime_profile','legacy'))
    except ValueError as exc:raise BitmapPackError(str(exc)) from exc
    return manifest


def validate_bitmaps(bitmaps: Any, *, runtime_profile='legacy') -> dict[str, int]:
    """Validate generated bitmap JSON and return its compact budget summary."""

    from compiler.bitmaps import normalize
    try:
        normalize(bitmaps,runtime_profile=runtime_profile)
    except ValueError as exc:
        raise BitmapPackError(str(exc)) from exc
    return {"sprites": len(bitmaps), "pixels": sum(b["width"] * b["height"] for b in bitmaps)}


def budget_report(bitmaps: list[dict[str, Any]], *, atlas_bytes: int | None = None, runtime_profile='legacy') -> dict[str, Any]:
    """Return a human/tool-friendly report without requiring Pillow."""

    limits=limits_for(runtime_profile)
    package_limit=limits["package_bytes"]
    usage = validate_bitmaps(bitmaps,runtime_profile=runtime_profile)
    wide = any("alpha" in b or b.get("encoding")=="indexed8-zlib" for b in bitmaps)
    max_pixels = limits["bitmap_pixels"] if runtime_profile=="resources-v2" else (BITMAP_V2["pixels"] if wide else MAX_PIXELS)
    max_size = [BITMAP_V2["width"], BITMAP_V2["height"]] if wide else [MAX_WIDTH, MAX_HEIGHT]
    atlas_bytes = atlas_bytes if atlas_bytes is not None else len(json.dumps(bitmaps, separators=(",", ":")).encode())
    warnings: list[str] = []
    if usage["pixels"] >= int(max_pixels * 0.75):
        warnings.append("总像素已达到设备上限的75%，请保留运行时绘制预算")
    if atlas_bytes >= int(package_limit * 0.75):
        warnings.append("atlas JSON 已接近游戏包上限，需减少素材或代码")
    return {
        "limits": {"sprites": limits["bitmap_count"], "sprite_size": max_size,
                   "pixels": max_pixels, "package_bytes": package_limit},
        "usage": {**usage, "atlas_bytes": atlas_bytes},
        "headroom": {"pixels": max_pixels - usage["pixels"],
                     "atlas_bytes": package_limit - atlas_bytes},
        "warnings": warnings,
    }


def _pillow():
    try:
        from PIL import Image, ImageOps  # type: ignore
    except ImportError as exc:  # pragma: no cover - depends on tool environment
        raise BitmapPackError("位图编译需要 Pillow，请按项目根目录 docs/AUTHORING.md 安装依赖") from exc
    return Image, ImageOps


def encode(image: Any, size: tuple[int, int], transparent: bool = True,
           alpha_threshold: int = 96, resample: str = "lanczos", trim: bool = True) -> dict[str, Any]:
    """Encode a Pillow image as one validated bitmap-v1 record."""

    Image, ImageOps = _pillow()
    image = image.convert("RGBA")
    filter_value = Image.Resampling.NEAREST if resample == "nearest" else Image.Resampling.LANCZOS
    if transparent:
        alpha = image.getchannel("A").point(lambda value: 255 if value >= alpha_threshold else 0)
        box = alpha.getbbox()
        if not box:
            raise BitmapPackError("透明 sprite 没有可见像素")
        if trim:
            image = ImageOps.contain(image.crop(box), size, filter_value)
            canvas = Image.new("RGBA", size)
            canvas.paste(image, ((size[0] - image.width) // 2, size[1] - image.height), image)
            image = canvas
        else:
            # Tiles and animation frames need their transparent cells and
            # original origin preserved; cropping can resurrect destroyed walls.
            image = image.resize(size, filter_value)
    else:
        # An opaque tile deliberately ignores source alpha; this is useful
        # for terrain/textures exported with an accidental alpha channel.
        image = image.convert("RGB").resize(size, filter_value).convert("RGBA")
    alpha = image.getchannel("A")
    quant = image.convert("RGB").quantize(colors=15, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    # Pillow can return only the colors present in a tiny/solid sprite.
    # bitmap-v1 still requires all sixteen slots, including transparent zero.
    colors = list(quant.getpalette() or [])
    colors += [0]*max(0,45-len(colors))
    palette = [0]
    for index in range(15):
        red, green, blue = colors[index * 3:index * 3 + 3]
        palette.append((red >> 3) << 11 | (green >> 2) << 5 | (blue >> 3))
    pixels = "".join("0" if value < alpha_threshold else format(index + 1, "x")
                     for index, value in zip(quant.getdata(), alpha.getdata()))
    result = {"width": size[0], "height": size[1],
              "palette": "".join(f"{color:04x}" for color in palette), "pixels": pixels}
    validate_bitmaps([result])
    return result


def _color_budget(value: Any) -> int:
    if type(value) is not int or not 1 <= value <= 255:
        raise BitmapPackError("max_colors 必须是1–255之间的整数")
    return value


def encode_v2(image: Any, size: tuple[int, int], *, transparent: bool = True,
              resample: str = "lanczos", trim: bool = False,
              max_colors: int = 255) -> dict[str, Any]:
    """Limit visible colour/alpha pairs without changing per-pixel coverage.

    Storage still has 256 palette slots and byte indices. Reducing this budget
    is lossy colour quantization, not a different runtime bitmap format.
    """
    Image, ImageOps = _pillow()
    _size(size, wide=True)
    _color_budget(max_colors)
    image = image.convert("RGBA" if transparent else "RGB").convert("RGBA")
    filt = Image.Resampling.NEAREST if resample == "nearest" else Image.Resampling.LANCZOS
    if transparent and trim:
        box = image.getchannel("A").point(lambda a: 255 if a >= 9 else 0).getbbox()
        if not box:
            raise BitmapPackError("透明 sprite 没有可见像素")
        fitted = ImageOps.contain(image.crop(box), size, filt)
        image = Image.new("RGBA", size)
        image.alpha_composite(fitted, ((size[0]-fitted.width)//2, size[1]-fitted.height))
    else:
        image = image.resize(size, filt)
    groups = {}
    for pos, (r, g, b, a) in enumerate(image.getdata()):
        level = (a * 15 + 127) // 255
        if level:
            groups.setdefault(level, []).append((pos, (r, g, b)))
    # At least one colour per coverage level; most slots go to populated levels.
    if len(groups) > max_colors:
        raise BitmapPackError("max_colors 小于素材的非零透明度级数，无法保留透明度")
    weights = {a: len(rows)**.75 for a, rows in groups.items()}
    total = sum(weights.values())
    shares = {a: (max_colors-len(groups))*weight/total for a, weight in weights.items()}
    budgets = {a: 1+int(share) for a, share in shares.items()}
    for a in sorted(shares, key=lambda a: (shares[a] % 1, a), reverse=True)[:max_colors-sum(budgets.values())]:
        budgets[a] += 1
    colors, opacity, pixels = [0], [0], [0] * (size[0]*size[1])
    for a, rows in sorted(groups.items()):
        strip = Image.new("RGB", (len(rows), 1))
        strip.putdata([rgb for _, rgb in rows])
        quant = strip.quantize(colors=budgets[a], method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
        palette = quant.getpalette()
        mapping = {}
        for (pos, _), index in zip(rows, quant.getdata()):
            if index not in mapping:
                r, g, b = palette[index*3:index*3+3]
                mapping[index] = len(colors)
                colors.append(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3))
                opacity.append(a)
            pixels[pos] = mapping[index]
    colors += [0] * (256-len(colors))
    opacity += [0] * (256-len(opacity))
    result = {"width": size[0], "height": size[1],
              "palette": "".join(f"{c:04x}" for c in colors),
              "alpha": "".join(f"{a:x}" for a in opacity),
              "pixels": "".join(f"{i:02x}" for i in pixels)}
    validate_bitmaps([result])
    return result


def decode(bitmap: dict[str, Any]) -> Any:
    """Decode either portable bitmap format to RGBA for source-art inspection."""
    Image, _ = _pillow()
    validate_bitmaps([bitmap])
    from compiler.bitmaps import unpack
    bitmap = unpack(bitmap)
    palette = [int(bitmap["palette"][i:i + 4], 16) for i in range(0, len(bitmap["palette"]), 4)]
    wide = "alpha" in bitmap
    stride = 2 if wide else 1
    pixels = bitmap["pixels"]
    values = (int(pixels[i:i + stride], 16) for i in range(0, len(pixels), stride))
    image = Image.new("RGBA", (bitmap["width"], bitmap["height"]))
    image.putdata([((palette[v] >> 11) * 255 // 31, ((palette[v] >> 5) & 63) * 255 // 63,
                    (palette[v] & 31) * 255 // 31,
                    int(bitmap["alpha"][v], 16) * 17 if wide else (255 if v else 0)) for v in values])
    return image


def _source_path(manifest_path: Path, value: str) -> Path:
    path = Path(value).expanduser()
    return path if path.is_absolute() else manifest_path.parent / path


def _crop(image: Any, sprite: dict[str, Any]) -> Any:
    if "rect" in sprite:
        x, y, width, height = _rect(sprite["rect"])
        return image.crop((x, y, x + width, y + height))
    if "cell" in sprite:
        cell_x, cell_y = sprite["cell"]
        cell_width, cell_height = _source_size(sprite["cell_size"], "cell_size")
        x, y = cell_x * cell_width, cell_y * cell_height
        return image.crop((x, y, x + cell_width, y + cell_height))
    return image


def compile_pack(manifest_path: str | Path, output_dir: str | Path | None = None,
                 *, write_preview: bool = True) -> dict[str, Any]:
    """Compile a source manifest and write atlas, manifest, budget and previews."""

    manifest_path = Path(manifest_path).expanduser().resolve()
    source_manifest = validate_manifest(json.loads(manifest_path.read_text(encoding="utf-8")))
    target = Path(output_dir).expanduser() if output_dir else manifest_path.parent / source_manifest.get("output", "compiled")
    target.mkdir(parents=True, exist_ok=True)
    preview_dir = target / "preview"
    if write_preview:
        preview_dir.mkdir(parents=True, exist_ok=True)
    image_cache: dict[Path, Any] = {}
    bitmaps: list[dict[str, Any]] = []
    records: list[dict[str, Any]] = []
    for index, sprite in enumerate(source_manifest["sprites"], 1):
        path = _source_path(manifest_path, sprite.get("file", source_manifest.get("source")))
        if path not in image_cache:
            Image, _ = _pillow()
            image_cache[path] = Image.open(path)
        image = _crop(image_cache[path], sprite)
        wide = sprite.get("encoding") == "indexed8-alpha4"
        size = _size(sprite["size"], f"{sprite['name']} size", wide=wide)
        bitmap = None if wide else encode(image, size, sprite.get("transparent", True),
                        sprite.get("alpha_threshold", 96), sprite.get("resample", "lanczos"),
                        sprite.get("trim", True))
        if wide:
            bitmap = encode_v2(image, size, transparent=sprite.get("transparent", True),
                               resample=sprite.get("resample", "lanczos"), trim=sprite.get("trim", True),
                               max_colors=sprite.get("max_colors", 255))
        bitmaps.append(bitmap)
        record: dict[str, Any] = {"id": index, "name": sprite["name"],
                                  "width": bitmap["width"], "height": bitmap["height"]}
        if "pivot" in sprite:
            record["pivot"] = list(sprite["pivot"])
        if "role" in sprite:
            record["role"] = sprite["role"]
        records.append(record)
        if write_preview:
            decode(bitmap).save(preview_dir / f"{index:02d}_{sprite['name']}.png")
    atlas_text = json.dumps(bitmaps, ensure_ascii=False, separators=(",", ":"))
    pack_manifest = {"format": "bitmap-v1", "sprites": {record["name"]: record["id"] for record in records},
                     "records": records, "pixels": sum(b["width"] * b["height"] for b in bitmaps),
                     "source_manifest": manifest_path.name}
    if 'animations' in source_manifest:
        animations(source_manifest['animations'],pack_manifest['sprites'],runtime_profile=source_manifest.get('runtime_profile','legacy'))
        pack_manifest['animations']=source_manifest['animations']
    runtime_profile=source_manifest.get("runtime_profile","legacy")
    bindings={'bitmaps':bitmaps,'sprite_manifest':pack_manifest,
              'data':bind_manifest(pack_manifest,bitmaps,runtime_profile=runtime_profile)}
    if runtime_profile!="legacy":bindings["runtime_profile"]=runtime_profile
    report = budget_report(bitmaps, atlas_bytes=len(atlas_text.encode()),runtime_profile=runtime_profile)
    (target / "atlas.json").write_text(atlas_text + "\n", encoding="utf-8")
    (target/'bindings.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (target / "manifest.json").write_text(json.dumps(pack_manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (target / "budget.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"output": str(target), "atlas": str(target / "atlas.json"),
            "manifest": str(target / "manifest.json"), "budget": report,
            "records": records,"bindings":str(target/'bindings.json')}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="编译 bitmap-v1 位图资源")
    parser.add_argument("manifest", type=Path, help="bitmap-pack/1 源图清单 JSON")
    parser.add_argument("--output-dir", type=Path, help="输出目录，默认 manifest 同目录/compiled")
    parser.add_argument("--no-preview", action="store_true", help="只输出 JSON，不写预览 PNG")
    args = parser.parse_args(argv)
    try:
        result = compile_pack(args.manifest, args.output_dir, write_preview=not args.no_preview)
    except (BitmapPackError, OSError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    print(json.dumps({"output": result["output"], "budget": result["budget"],
                      "files": [result["atlas"], result["manifest"], result["bindings"]]},
                     ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":  # pragma: no cover - exercised by the CLI
    raise SystemExit(main())
